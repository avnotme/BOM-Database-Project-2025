package app;

import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;



public class JDBCConnection {

    public static final String DATABASE = "jdbc:sqlite:database/climate.db";

    public JDBCConnection() {
        System.out.println("Created JDBC Connection Object");
    }

    public ArrayList<FLAG> getFlags() {

        ArrayList<FLAG> flags = new ArrayList<FLAG>();

        Connection connection = null;

        try {
            connection = DriverManager.getConnection(DATABASE);

            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);

            String query = "SELECT * FROM FlagQuality";
            
            ResultSet results = statement.executeQuery(query);

            while (results.next()) {
                String flagtype     = results.getString("flag");
                String description  = results.getString("description");

                FLAG flagsObj = new FLAG(flagtype, description);

                flags.add(flagsObj);
            }

            statement.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                System.err.println(e.getMessage());
            }
        }

        return flags;
    }
    public static List<String> getDataTypes() {
        List<String> Fields = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Label FROM Metadata ORDER BY Label";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Fields.add(rs.getString("Label"));
            }
        } catch (SQLException e) {
            Fields.add("Error loading stations");
        }
        return Fields;
    }
    public static List<String> getDataInfo(String field) {
    List<String> info = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Description FROM Metadata WHERE Label = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, field);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Description"));
            }
        } catch (SQLException e) {
            info.add("Error loading data info");
        }


        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Label FROM Metadata WHERE Label = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, field);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Label"));
            }
        } catch (SQLException e) {
            info.add("Error loading data info");
        }


        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Unit FROM Metadata WHERE Label = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, field);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Unit"));
            }
        } catch (SQLException e) {
            info.add("Error loading data info");
        }


        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Purpose FROM Metadata WHERE Label = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, field);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Purpose"));
            }
        } catch (SQLException e) {
            info.add("Error loading data info");
        }

        return info;

        
        

    }  
    public static String getDatasetDescription(String dataset) {
        String info = "";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Description FROM Datasets WHERE Dataset = ?"; 
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, dataset);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info = rs.getString("Description");
            }
        } catch (SQLException e) {
            info = "Error loading dataset info";
        }
        return info;
    } 
    public static List<String> getDatasetDataList(String dataset) {
        List<String> info = new ArrayList<>();
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        try (Connection conn = DriverManager.getConnection(dbPath)) {
            String sql = null;
            switch (dataset) {
                case "ClimateData":
                    sql = "SELECT Data FROM ClimateDataset";
                    break;
                case "Flag":
                    sql = "SELECT Data FROM FlagDataset";
                    break;
                case "DateTime":
                    sql = "SELECT Data FROM DateDataset";
                    break;
                case "Location":
                    sql = "SELECT Data FROM LocationDataset";
                    break;
                case "Metadata":
                    sql = "SELECT Data FROM Metadata";
                    break;
                case "Personas":
                    sql = "SELECT Data FROM PersonasDataset";
                    break;
                case "Team":
                    sql = "SELECT Data FROM TeamDataset";
                    break;
                default:
                    info.add("Unknown dataset");
                    return info;
            }
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString(1));
            }
        } catch (SQLException e) {
            info.add("Error loading dataset info");
        }
        return info;
    }
    public static List<String> getDatasetAttributesList(String dataset) {
        List<String> info = new ArrayList<>();
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        String sql = null;
        switch (dataset) {
            case "ClimateData":
                sql = "SELECT Attribute FROM ClimateDataset";
                break;
            case "DateTime":
                sql = "SELECT Attribute FROM DateDataset";
                break;
            case "Flag":
                sql = "SELECT Attribute FROM FlagDataset";
                break;
            case "Location":
                sql = "SELECT Attribute FROM LocationDataset";
                break;
            case "Metadata":
                sql = "SELECT Attribute FROM Metadata";
                break;
            case "Personas":
                sql = "SELECT Attribute FROM PersonasDataset";
                break;
            case "Team":
                sql = "SELECT Attribute FROM TeamDataset";
                break;
            default:
                info.add("Unknown dataset");
                return info;
        }
        try (Connection conn = DriverManager.getConnection(dbPath)) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Attribute"));
            }
        } catch (SQLException e) {
            info.add("Error loading dataset attributes");
        }
        return info;
    }
    public static List<String> getDatasetDescriptionsList(String dataset) {
        List<String> info = new ArrayList<>();
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        String sql = null;
        switch (dataset) {
            case "ClimateData":
                sql = "SELECT Description FROM ClimateDataset";
                break;
            case "DateTime":
                sql = "SELECT Description FROM DateDataset";
                break;
            case "Flag":
                sql = "SELECT Description FROM FlagDataset";
                break;
            case "Location":
                sql = "SELECT Description FROM LocationDataset";
                break;
            case "Metadata":
                sql = "SELECT Description FROM Metadata";
                break;
            case "Personas":
                sql = "SELECT Description FROM PersonasDataset";
                break;
            case "Team":
                sql = "SELECT Description FROM TeamDataset";
                break;
            default:
                info.add("Unknown dataset");
                return info;
        }
        try (Connection conn = DriverManager.getConnection(dbPath)) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                info.add(rs.getString("Description"));
            }
        } catch (SQLException e) {
            info.add("Error loading dataset description");
        }
        return info;
    }    
    public static List<String> getDatasetNames() {
        List<String> datasetNames = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Dataset FROM Datasets ORDER BY Dataset";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                datasetNames.add(rs.getString("Dataset"));
            }
        } catch (SQLException e) {
            datasetNames.add("Error loading dataset names");
        }
        return datasetNames;
    }
    public static List<String> getQualityFlags() {
        List<String> qualityFlags = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT FD FROM Flag ORDER BY FD";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                qualityFlags.add(rs.getString("FD"));
            }
        } catch (SQLException e) {
            qualityFlags.add("Error loading quality flags");
        }
        return qualityFlags;
    }
    public static List<String> getClimateQualityList(){
        List<String> climateQualityList = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT Label FROM Metadata WHERE Label LIKE '%Quality%' ORDER BY Label";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                climateQualityList.add(rs.getString("Label"));
            }
        } catch (SQLException e) {
            climateQualityList.add("Error loading climate quality list");
        }
        return climateQualityList;
    }
    public static List<List<String>> getClimateDataRows(
        String metricCol, String qualityCol, String periodStart, String periodEnd, List<String> sites, String refQuality) {
        List<List<String>> rows = new ArrayList<>();
        String sql = "SELECT c.Site, l.Name AS Location, c.Date, c.[" + metricCol + "], c.[" + qualityCol + "] " +
                     "FROM ClimateData c " +
                     "LEFT JOIN Location l ON c.Site = l.Site " +
                     "WHERE 1=1";
        List<String> params = new ArrayList<>();
        if (periodStart != null && !periodStart.isEmpty()) {
            sql += " AND c.Date >= ?";
            params.add(periodStart);
        }
        if (periodEnd != null && !periodEnd.isEmpty()) {
            sql += " AND c.Date <= ?";
            params.add(periodEnd);
        }
        if (sites != null && !sites.isEmpty()) {
            sql += " AND c.Site IN (" + String.join(",", java.util.Collections.nCopies(sites.size(), "?")) + ")";
            params.addAll(sites);
        }
        if (refQuality != null && !refQuality.isEmpty()) {
            sql += " AND c.[" + qualityCol + "] = ?";
            params.add(refQuality);
        }
        sql += " ORDER BY c.Date, c.Site";
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            PreparedStatement ps = conn.prepareStatement(sql);
            for (int i = 0; i < params.size(); i++) {
                ps.setString(i + 1, params.get(i));
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                List<String> row = new ArrayList<>();
                row.add(rs.getString("Site"));      
                row.add(rs.getString("Location"));  
                row.add(rs.getString("Date"));
                row.add(rs.getString(metricCol));
                row.add(rs.getString(qualityCol));
                rows.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }
    public static List<String> getAllSites() {
    List<String> sites = new ArrayList<>();
    try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
        String sql = "SELECT DISTINCT Site FROM ClimateData ORDER BY Site";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            sites.add(rs.getString("Site"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        sites.add("Error loading sites");
    }
    return sites;
}
    public static List<String> getAllStates() {
    List<String> states = new ArrayList<>();
    try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
        String sql = "SELECT DISTINCT State FROM Location ORDER BY State";
        PreparedStatement ps = conn.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            states.add(rs.getString("State"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        states.add("Error loading sites");
    }
    return states;}
    public static Integer[] getFlagCount(){
        Integer[] arr = new Integer[6];
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'Y'";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                arr[0] = rs.getInt(1);
            }
            sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'N'";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                arr[1] = rs.getInt(1);
            }
            sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'W'";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                arr[2] = rs.getInt(1);
            }
            sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'S'";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) { 
                arr[3] = rs.getInt(1);
            }
            sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'I'";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                arr[4] = rs.getInt(1);
            }
            sql = "SELECT COUNT(*) FROM FlagQuality WHERE flag = 'X'";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                arr[5] = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            for (int i = 0; i < arr.length; i++) {
                arr[i] = 0;
            }
        }

        return arr;
    }
    public static Integer[] getFlagCount(String state, String periodStart, String periodEnd) {
        Integer[] arr = new Integer[6];
        String[] flags = {"Y", "N", "W", "S", "I", "X"};
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            for (int i = 0; i < flags.length; i++) {
                String sql = "SELECT COUNT(*) FROM ClimateData c " +
                             "JOIN Location l ON c.Site = l.Site " +
                             "WHERE c.Flag = ? AND l.State = ?";
                if (periodStart != null && !periodStart.isEmpty()) {
                    sql += " AND c.Date >= ?";
                }
                if (periodEnd != null && !periodEnd.isEmpty()) {
                    sql += " AND c.Date <= ?";
                }
                PreparedStatement ps = conn.prepareStatement(sql);
                int paramIdx = 1;
                ps.setString(paramIdx++, flags[i]);
                ps.setString(paramIdx++, state);
                if (periodStart != null && !periodStart.isEmpty()) {
                    ps.setString(paramIdx++, periodStart);
                }
                if (periodEnd != null && !periodEnd.isEmpty()) {
                    ps.setString(paramIdx++, periodEnd);
                }
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    arr[i] = rs.getInt(1);
                } else {
                    arr[i] = 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            for (int i = 0; i < arr.length; i++) {
                arr[i] = 0;
            }
        }
        return arr;
    }
    public static Integer[] getFlagCount(String state, String periodStart, String periodEnd, String qualCol) {
        Integer[] arr = new Integer[6];
        String[] flags = {"Y", "N", "W", "S", "I", "X"};
        if (qualCol == null || qualCol.trim().isEmpty()) {
            for (int i = 0; i < arr.length; i++) arr[i] = 0;
            return arr;
        }
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            for (int i = 0; i < flags.length; i++) {
                String sql = "SELECT COUNT(*) FROM ClimateData c " +
                             "JOIN Location l ON c.Site = l.Site " +
                             "WHERE c.[" + qualCol + "] = ? AND l.State = ?";
                if (periodStart != null && !periodStart.isEmpty()) {
                    sql += " AND c.Date >= ?";
                }
                if (periodEnd != null && !periodEnd.isEmpty()) {
                    sql += " AND c.Date <= ?";
                }
                PreparedStatement ps = conn.prepareStatement(sql);
                int paramIdx = 1;
                ps.setString(paramIdx++, flags[i]);
                ps.setString(paramIdx++, state);
                if (periodStart != null && !periodStart.isEmpty()) {
                    ps.setString(paramIdx++, periodStart);
                }
                if (periodEnd != null && !periodEnd.isEmpty()) {
                    ps.setString(paramIdx++, periodEnd);
                }
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    arr[i] = rs.getInt(1);
                } else {
                    arr[i] = 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            for (int i = 0; i < arr.length; i++) {
                arr[i] = 0;
            }
        }
        return arr;
    }

    public static List<String> getClimateMetricList(){
        List<String> climateMetricList = new ArrayList<>();
        climateMetricList.add("Daily Rainfall");
        climateMetricList.add("Consecutive Rainy Days");
        climateMetricList.add("Accumulated Days Rain");
        climateMetricList.add("Evaporation");
        climateMetricList.add("Accumulated Days Evap");
        climateMetricList.add("Maximum Temperature");
        climateMetricList.add("Accumulated Days MaxTemp");
        climateMetricList.add("Minimum Temperature");
        climateMetricList.add("Accumulated Days MinTemp");
        climateMetricList.add("Humidity at 00");
        climateMetricList.add("Humidity at 03");
        climateMetricList.add("Humidity at 06");
        climateMetricList.add("Humidity at 09");
        climateMetricList.add("Humidity at 12");
        climateMetricList.add("Humidity at 15");
        climateMetricList.add("Humidity at 18");
        climateMetricList.add("Humidity at 21");
        climateMetricList.add("Sunshine");
        climateMetricList.add("Cloud Cover at 00");
        climateMetricList.add("Cloud Cover at 03");
        climateMetricList.add("Cloud Cover at 06");
        climateMetricList.add("Cloud Cover at 09");
        climateMetricList.add("Cloud Cover at 12");
        climateMetricList.add("Cloud Cover at 15");
        climateMetricList.add("Cloud Cover at 18");
        climateMetricList.add("Cloud Cover at 21");
        return climateMetricList;
    }    
    public static List<String> getStationsList(){
                List<String> stationNames = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT DISTINCT Name FROM Location ORDER BY Name";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                stationNames.add(rs.getString("Name"));
            }
        } catch (SQLException e) {
            stationNames.add("Error loading stations");
        }
        return stationNames;
    }
    public static int getTotalClimate(String metricDisplayName, int startYear, int endYear, String stationName) {
        int total = 0;
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";

        String[] mapping = ClimateMappings.METRIC_MAP2.get(metricDisplayName);
        String dbMetricCol = (mapping != null) ? mapping[0] : metricDisplayName;

        String sql = "SELECT COALESCE(SUM(c.[%s]), 0) as total " +
                     "FROM ClimateData c " +
                     "JOIN Location l ON c.Site = l.Site " +
                     "JOIN DateTime d ON c.Date = d.Date " +
                     "WHERE d.Year >= ? AND d.Year <= ? AND l.Name = ?";
        sql = String.format(sql, dbMetricCol);

        try (Connection conn = DriverManager.getConnection(dbPath)) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, startYear);
            ps.setInt(2, endYear);
            ps.setString(3, stationName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }
    public static List<String> getNonQualityClimateMetrics() {
        List<String> metrics = new ArrayList<>();
        for (Map.Entry<String, String[]> entry : ClimateMappings.METRIC_MAP2.entrySet()) {
            if (entry.getValue().length > 0) {
                metrics.add(entry.getKey());
            }
        }
        return metrics;
    }
    public static List<List<String>> getClimateTableRows(
        String metricCol, String periodStart, String periodEnd, int minSite, int maxSite, String state) {
        List<List<String>> rows = new ArrayList<>();
        if (metricCol == null || metricCol.trim().isEmpty()) return rows;

        // Use ClimateMappings to get the correct DB column name for the metric
        String[] mapping = ClimateMappings.METRIC_MAP2.get(metricCol);
        String dbMetricCol = (mapping != null && mapping.length > 0) ? mapping[0] : metricCol;

        String sql = "SELECT c.Site, l.Name AS Location, c.Date, l.State, c.[" + dbMetricCol + "] AS MetricValue " +
                     "FROM ClimateData c " +
                     "JOIN Location l ON c.Site = l.Site " +
                     "WHERE 1=1 ";
        List<Object> params = new ArrayList<>();

        if (state != null && !state.isEmpty()) {
            sql += "AND l.State = ? ";
            params.add(state);
        }
        if (periodStart != null && !periodStart.isEmpty()) {
            sql += "AND c.Date >= ? ";
            params.add(periodStart);
        }
        if (periodEnd != null && !periodEnd.isEmpty()) {
            sql += "AND c.Date <= ? ";
            params.add(periodEnd);
        }
        sql += "AND c.Site >= ? AND c.Site <= ? ";
        params.add(minSite);
        params.add(maxSite);

        sql += "ORDER BY c.Site, c.Date";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            PreparedStatement ps = conn.prepareStatement(sql);
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                List<String> row = new ArrayList<>();
                row.add(rs.getString("Site"));
                row.add(rs.getString("Location"));
                row.add(rs.getString("Date"));
                row.add(rs.getString("State"));
                row.add(rs.getString("MetricValue"));
                rows.add(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }
}
