package app;

import io.javalin.Javalin;
import io.javalin.core.util.RouteOverviewPlugin;

public class App {

    public static final int         JAVALIN_PORT    = 7001;
    public static final String      CSS_DIR         = "css/";
    public static final String      IMAGES_DIR      = "images/";

    public static void main(String[] args) {
        Javalin app = Javalin.create(config -> {
            config.registerPlugin(new RouteOverviewPlugin("/help/routes"));
            
            config.addStaticFiles(CSS_DIR);

            config.addStaticFiles(IMAGES_DIR);
        }).start(JAVALIN_PORT);


        configureRoutes(app);
    }

    public static void configureRoutes(Javalin app) {
        app.get(PageIndex.URL, new PageIndex());
        app.get(PageMission.URL, new PageMission());
        app.get(PageAbout.URL, new PageAbout());
        app.get(PageST2A.URL, new PageST2A());
        app.get(PageST2B.URL, new PageST2B());
        app.get(PageST2C.URL, new PageST2C());
        app.get(PageST3A.URL, new PageST3A());
        app.get(PageST3B.URL, new PageST3B());
        app.get(PageST3C.URL, new PageST3C());

        app.post(PageIndex.URL, new PageIndex());
        app.post(PageAbout.URL, new PageAbout());
        app.post(PageST2A.URL, new PageST2A());
        app.post(PageST3A.URL, new PageST3A());

        app.get("/persona-block", ctx -> {
            String name = ctx.queryParam("name");
            if ("all-personas".equals(name)) {
                ctx.html(Personas.getAllBlock());
            } else {
                String[] persona = Personas.getPersonaDetails(name);
                ctx.html(Personas.getPersonaBlock(persona));
            }
        });
    }

}
