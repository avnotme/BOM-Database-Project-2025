package app;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.sql.*;
import java.util.ArrayList;

public class PageST2A implements Handler {

    public static final String URL = "/page2A.html";

    @Override
    public void handle(Context context) throws Exception {

        String selectedState = context.queryParam("state");
        String latStartStr = context.queryParam("lat_start");
        String latEndStr = context.queryParam("lat_end");
        String selectedMetric = context.queryParam("metric");
        String selectedYear = context.queryParam("year");

        double latStart = (latStartStr != null && !latStartStr.isEmpty()) ? Double.parseDouble(latStartStr) : -70.0;
        double latEnd = (latEndStr != null && !latEndStr.isEmpty()) ? Double.parseDouble(latEndStr) : 0.0;
        if (selectedYear == null || selectedYear.isEmpty()) selectedYear = "2020";
        if (selectedMetric == null || selectedMetric.isEmpty()) selectedMetric = "MaxTemp";

        String metricColumn;
        String metricLabel;
        switch (selectedMetric) {
    case "MinTemp" -> {
        metricColumn = "MinTemp";
        metricLabel = "Min Temperature";
    }
    case "Precipitation" -> {
        metricColumn = "Precipitation";
        metricLabel = "Rainfall";
    }
    case "Evaporation" -> {
        metricColumn = "Evaporation";
        metricLabel = "Evaporation (mm)";
    }
    case "CloudCover" -> {
        metricColumn = "Okta09"; 
        metricLabel = "Cloud Cover (Okta at 9AM)";
    }
    case "Sunshine" -> {
        metricColumn = "Sunshine";
        metricLabel = "Sunshine Hours";
    }
    default -> {
        metricColumn = "MaxTemp";
        metricLabel = "Max Temperature";
    }
}


        ArrayList<String> stationRows = new ArrayList<>();
        StringBuilder jsStations = new StringBuilder("const stations = [\n");
        int stationCount = 0;

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sortBy = context.queryParam("sort_by");
            String orderBy = "l.Name"; 
            if ("site".equals(sortBy)) orderBy = "l.Site";
            else if ("region".equals(sortBy)) orderBy = "l.Region";
            else if ("lat".equals(sortBy)) orderBy = "l.Lat";

            String sql = "SELECT l.Site, l.Name, l.Region, l.Lat, l.Long, AVG(c." + metricColumn + ") AS MetricValue " +
             "FROM Location l " +
             "JOIN ClimateData c ON l.Site = c.Site " +
             "JOIN DateTime d ON c.Date = d.Date " +
             "WHERE l.State = ? AND CAST(l.Lat AS REAL) BETWEEN ? AND ? " +
             "AND d.Year = ? AND c." + metricColumn + " IS NOT NULL " +
             "GROUP BY l.Site, l.Name, l.Region, l.Lat, l.Long " +
             "ORDER BY " + orderBy + ";";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, selectedState);
            ps.setDouble(2, latStart);
            ps.setDouble(3, latEnd);
            ps.setString(4, selectedYear); 

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String site = rs.getString("Site");
                String name = rs.getString("Name");
                String region = rs.getString("Region");
                double lat = rs.getDouble("Lat");
                double lon = rs.getDouble("Long");
                double metricValue = rs.getDouble("MetricValue");

                stationCount++;
                String row = String.format("<tr%s><td>%s</td><td>%s</td><td>%s</td><td>%.4f</td><td>%.1f</td></tr>",
                    (stationCount > 5 ? " class='extra-station-row' style='display:none;'" : ""),
                    site, name, region, lat, metricValue);
                stationRows.add(row);

                jsStations.append(String.format("{ name: '%s', lat: %f, lon: %f },\n", name.replace("'", "\\'"), lat, lon));
            }
            jsStations.append("];");
        } catch (SQLException e) {
            stationRows.add("<tr><td colspan='4'>Error loading stations: " + e.getMessage() + "</td></tr>");
        }

        ArrayList<String> summaryRows = new ArrayList<>();
        int rowCount = 0;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            String sql = "SELECT l.Region, COUNT(DISTINCT l.Site) AS NumStations, AVG(c." + metricColumn + ") AS AvgMetric FROM Location l JOIN ClimateData c ON l.Site = c.Site JOIN DateTime d ON c.Date = d.Date WHERE l.State = ? AND CAST(l.Lat AS REAL) BETWEEN ? AND ? AND d.Year = ? AND c." + metricColumn + " IS NOT NULL GROUP BY l.Region ORDER BY l.Region;";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, selectedState);
            ps.setDouble(2, latStart);
            ps.setDouble(3, latEnd);
            ps.setString(4, selectedYear);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String region = rs.getString("Region");
                int numStations = rs.getInt("NumStations");
                double avgMetric = rs.getDouble("AvgMetric");
                rowCount++;
                String row = String.format("<tr%s><td>%s</td><td>%d</td><td>%.1f</td></tr>",
                        (rowCount > 5 ? " class='extra-summary-row' style='display:none;'" : ""), region, numStations, avgMetric);
                summaryRows.add(row);
            }
        } catch (SQLException e) {
            summaryRows.add("<tr><td colspan='3'>Error loading summary: " + e.getMessage() + "</td></tr>");
        }

        String html = "<html><head><meta charset='UTF-8'><title>Climate In Your Area</title>" +
            "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css' />" +
            "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>" +
            "<link rel='stylesheet' type='text/css' href='common.css' />" +
            "<link rel='stylesheet' type='text/css' href='Homepage.css' />" +
            "</head><body>";

            html += CommonElements.getProgressBar();
            html += CommonElements.getNavbar()  + CommonElements.getHeader();

              html += """
                <section class='hero'>
                    <h2>Explore Climate Trends In Your Area!</h2>
                    <p>This interactive tool allows you to filter and find over 50 years of climate data (1970–2020) from the Bureau of Meteorology. 
                    Discover how temperature and rainfall have changed in different states and regions over time.</p>
                    <p>Use the filters to select your state, narrow down by latitude, and explore metrics such as maximum temperature, minimum temperature, and rainfall for a specific year.</p>
                </section>

                <section class='hero'>
                <h2>Understanding Latitude Filters</h2>
                <p>
                    The <strong>Latitude Start</strong> and <strong>Latitude End</strong> fields allow you to filter climate data 
                    based on how far north or south a weather station is located in Australia.
                </p>
                <p>
                    Latitude values range from around <strong>-43° (South)</strong> in Tasmania to <strong>-10° (North)</strong> in Queensland.
                    By entering a range (e.g.,-38 to -28), you can focus on climate in a specific area.
                </p>
            </section>
            """;
                
        html += "<div class='content'><div class='filter-data-panel'><div class='filter-controls'>" +
            "<form method='get' action='/page2A.html'>" +
            "<h2>Filter Controls</h2>" +
            "<label>State:</label>" +
            "<select name='state'>" +
            "<option value=''>-- Select State --</option>" +
            "<option value='VIC'" + ("VIC".equals(selectedState) ? " selected" : "") + ">VIC</option>" +
            "<option value='N.S.W.'" + ("N.S.W.".equals(selectedState) ? " selected" : "") + ">NSW</option>" +
            "<option value='QLD'" + ("QLD".equals(selectedState) ? " selected" : "") + ">QLD</option>" +
            "<option value='W.A.'" + ("W.A.".equals(selectedState) ? " selected" : "") + ">WA</option>" +
            "<option value='S.A.'" + ("S.A.".equals(selectedState) ? " selected" : "") + ">SA</option>" +
            "<option value='TAS'" + ("TAS".equals(selectedState) ? " selected" : "") + ">TAS</option>" +
            "<option value='N.T.'" + ("N.T.".equals(selectedState) ? " selected" : "") + ">NT</option>" +
            "</select><br>" +
            "<label>Latitude Start:</label><input type='number' name='lat_start' step='0.01' value='" + latStart + "' required><br>" +
            "<label>Latitude End:</label><input type='number' name='lat_end' step='0.01' value='" + latEnd + "' required><br>" +
            "<label>Metric:</label><select name='metric'>" +
            "<option value='MaxTemp'" + ("MaxTemp".equals(selectedMetric) ? " selected" : "") + ">Max Temperature</option>" +
            "<option value='MinTemp'" + ("MinTemp".equals(selectedMetric) ? " selected" : "") + ">Min Temperature</option>" +
            "<option value='Precipitation'" + ("Precipitation".equals(selectedMetric) ? " selected" : "") + ">Rainfall</option>" +
            "<option value='Evaporation'" + ("Evaporation".equals(selectedMetric) ? " selected" : "") + ">Evaporation</option>" +
            "<option value='CloudCover'" + ("CloudCover".equals(selectedMetric) ? " selected" : "") + ">Cloud Cover (Okta at 9AM)</option>" +
            "<option value='Sunshine'" + ("Sunshine".equals(selectedMetric) ? " selected" : "") + ">Sunshine Hours</option>" +
            "</select><br>"
            +
        "<label>Year:</label><input type='number' name='year' value='" + selectedYear + "' required><br>" +
        "<label>Sort By:</label>" +
        "<select name='sort_by'>" +
        "<option value='name'" + ("name".equals(context.queryParam("sort_by")) ? " selected" : "") + ">Name</option>" +
        "<option value='site'" + ("site".equals(context.queryParam("sort_by")) ? " selected" : "") + ">Site</option>" +
        "<option value='region'" + ("region".equals(context.queryParam("sort_by")) ? " selected" : "") + ">Region</option>" +
        "<option value='lat'" + ("lat".equals(context.queryParam("sort_by")) ? " selected" : "") + ">Latitude</option>" +
        "</select><br><br>" +
        "<button type='submit'>Apply</button></form></div>" +

        "<div class='data-table-panel'><h3>Weather Stations</h3>" +
        "<div id='stationMap' style='width:100%;height:300px;margin-bottom:20px;'></div>" +
        "<table class='station-table'>" +
        "<thead><tr><th>Site</th><th>Name</th><th>Region</th><th>Lat</th><th>Avg. " + metricLabel + "</th></tr></thead>" +
        "<tbody>" + String.join("\n", stationRows) + "</tbody></table>";

        if (stationCount > 5) html += "<button onclick=\"showMoreStationRows()\">Show More</button>";

        html += "<h3>Summary by Region</h3><table class='station-table'><thead><tr><th>Region</th><th># Stations</th><th>Avg. " + metricLabel + "</th></tr></thead><tbody>" +
                 String.join("\n", summaryRows) +
                 "</tbody></table>";

        if (rowCount > 5) html += "<button onclick=\"showMoreSummaryRows()\">Show More</button>";

        html += "</div></div></div>";

        html += "<script>" + jsStations +
            "const map = L.map('stationMap').setView([-25, 135], 4);\n" +
            "L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(map);\n" +
            "stations.forEach(s => { L.marker([s.lat, s.lon]).addTo(map).bindPopup(`<b>${s.name}</b>`); });\n" +
            "function showMoreStationRows() { document.querySelectorAll('.extra-station-row').forEach(row => row.style.display = ''); event.target.style.display = 'none'; }\n" +
            "function showMoreSummaryRows() { document.querySelectorAll('.extra-summary-row').forEach(row => row.style.display = ''); event.target.style.display = 'none'; }" +
            "</script>";

        html += CommonElements.getFooter();
        html += "</body></html>";

        context.contentType("text/html; charset=UTF-8");
        context.html(html);
    }
}
