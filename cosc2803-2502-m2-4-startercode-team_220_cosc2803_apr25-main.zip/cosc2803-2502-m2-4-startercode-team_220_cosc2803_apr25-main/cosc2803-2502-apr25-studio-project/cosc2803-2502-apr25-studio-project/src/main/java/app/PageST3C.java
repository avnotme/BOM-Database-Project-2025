package app;

import java.util.ArrayList;
import java.util.List;
import io.javalin.http.Context;
import io.javalin.http.Handler;

public class PageST3C implements Handler {

    public static final String URL = "/page3C.html";

    @Override
    public void handle(Context context) throws Exception {
        // Query Parameters for "Assess Climate Data Quality" Filter
        String refQuality = context.queryParam("ref_quality");
        String refMetric = context.queryParam("ref_metric");
        String period1Start = context.queryParam("period1_start");
        String period1End = context.queryParam("period1_end");
        String period2Start = context.queryParam("period2_start");
        String period2End = context.queryParam("period2_end");
        String refSites = context.queryParam("ref_sites");
        String refStation = context.queryParam("ref_station");

        // Parse Sites List
        List<String> refSitesList = new ArrayList<>();
        if (refSites != null && !refSites.trim().isEmpty()) {
            for (String s : refSites.split(",")) {
                if (!s.trim().isEmpty()) {
                    refSitesList.add(s.trim());
                }
            }
        }

        // Get Dropdown Data
        List<String> allSites = JDBCConnection.getAllSites();
        List<String> refMetricList = JDBCConnection.getClimateMetricList();
        List<String> stationNames = JDBCConnection.getStationsList();

        // Get interval selection
        String interval = context.queryParam("Interval");
        if (interval == null) interval = "";

        // HTML Head and Navbar
        String html = "<html>";
        html += "<head>"
             + "<title>Subtask 2.3</title>"
             + "<link rel='stylesheet' type='text/css' href='common.css' />"
             + "<link rel='stylesheet' type='text/css' href='Homepage.css' />"
             + "</head>";
        html += "<body>";
        html += CommonElements.getProgressBar();
        html += CommonElements.getNavbar() + CommonElements.getHeader();

        // Hero Section
        html += """
        <section class='hero'>
            <h2>Weather Correlation</h2>
            <p>This page allows users to analyse correlations between climate metrics by selecting a specific time
            period, choosing a reference weather station and a climate metric.</p>
            <p>By utilising these filters, users can uncover meaningful relationships and patterns in climate data,
            enhancing their understanding of envioronmental interations over time.</p>
        </section>
        """;

        // Content and Filter Panel
        html += """
        <div class='content'>
            <div class='main-panel'>
                <div class='main-info'>
                    <h2>Weather Correlation in a  Station</h2>
                    <p>Use this tool to investingate Weather Correlation between metrics in a specific station.</p>
                </div>
            </div>
            <div class='filter-data-panel'>
                <div class='filter-controls'>
                    <h3>Filter & Controls Panel</h3>
                    <form method='get' action='/page3C.html'>
                        <label>Reference Metric:</label>
                        <select name='ref_metric' required>
                            <option value=''>Select Reference Metric</option>
        """;

        for (String name : refMetricList) {
            html += "<option value='" + name + "'" + (name.equals(refMetric) ? " selected" : "") + ">" + name + "</option>";
        }

        html += "</select>"
             + "<br><br>"
             + "<label>Reference Station Selector:</label>"
             + "<select name='ref_station' required>"
             + "<option value=''>Select Reference Station</option>";
        for (String name : stationNames) {
            html += "<option value='" + name + "'" + (name.equals(refStation) ? " selected" : "") + ">" + name + "</option>";
        }
        html += "</select>"
             + "<br><br>"
             + "<label>Time Interval:</label>"
             + "<select name='Interval' id='interval-select' required>"
             + "<option value='' " + (interval.isEmpty() ? "selected" : "") + ">-- Please select an interval --</option>"
             + "<option value='Year'" + ("Year".equals(interval) ? " selected" : "") + ">Year</option>"
             + "<option value='Half Decade'" + ("Half Decade".equals(interval) ? " selected" : "") + ">Half Decade</option>"
             + "<option value='Decade'" + ("Decade".equals(interval) ? " selected" : "") + ">Decade</option>"
             + "</select>"
             + "<br><br>"
             + "<div id='time-range-picker' style='display:none;'>"
             + "<label>Time Range:</label>"
             + "<input type='number' name='period1_start' value='" + (period1Start != null ? period1Start : "1970") + "' min='1970' max='2020' required>"
             + "<input type='number' name='period1_end' value='" + (period1End != null ? period1End : "2020") + "' min='1970' max='2020' required>"
             + "<br><br>"
             + "</div>"
             + "<button type='submit'>Compare</button>"
             + "<button type='reset'>Cancel</button>"
             + "<a href='/page3C.html' style='margin-left:10px;'><button type='button'>Clear</button></a>"
             + "</form>"
             + "</div>";

        // Parsing Periods as Integers
        int p1Start = 0, p1End = 0;
        try {
            p1Start = period1Start != null ? Integer.parseInt(period1Start) : 0;
            p1End = period1End != null ? Integer.parseInt(period1End) : 0;
        } catch (NumberFormatException e) {
        }

        // Interval validation
        int requiredRange = 1;
        if ("Year".equals(interval)) {
            requiredRange = 1;
        } else if ("Half Decade".equals(interval)) {
            requiredRange = 10;
        } else if ("Decade".equals(interval)) {
            requiredRange = 20;
        }

        html = html.replace(
            "<input type='number' name='period1_start'",
            "<input type='number' name='period1_start' required"
        );
        html = html.replace(
            "<input type='number' name='period1_end'",
            "<input type='number' name='period1_end' required"
        );

        html = html.replace(
            "<input type='number' name='period1_end' value='" + (period1End != null ? period1End : "2020") + "' min='1900' max='2025' required>",
            "<input type='number' name='period1_end' value='" + (period1End != null ? period1End : "2020") + "' min='1970' max='2020' required oninput='validateRange()'>"
        );

        // JavaScript function inspirations:
        // getRequiredRange: https://developer.mozilla.org/en-US/docs/Web/API/HTMLSelectElement
        // lockPeriods: https://stackoverflow.com/questions/3437786/html-input-textbox-onchange-event
        // validateRange: https://developer.mozilla.org/en-US/docs/Web/Guide/HTML/Constraint_validation
        // showTimeRangePicker: https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/style
        // DOMContentLoaded event: https://developer.mozilla.org/en-US/docs/Web/API/Document/DOMContentLoaded_event
        //Implemented here by: @avnotme.

        html += """
        <script>
        function getRequiredRange() { 
            var interval = document.getElementById('interval-select').value;
            if (interval === "Year") return 2;
            if (interval === "Half Decade") return 10;
            if (interval === "Decade") return 20;
            return 1;
        }

        function lockPeriods(changed) { 
            var start = document.getElementsByName('period1_start')[0];
            var end = document.getElementsByName('period1_end')[0];
            var required = getRequiredRange();
            var minYear = 1970, maxYear = 2020;
            if (changed === 'start' && start.value) {
                var newEnd = parseInt(start.value) + required - 1;
                if (newEnd > maxYear) {
                    start.value = maxYear - required + 1;
                    newEnd = maxYear;
                }
                end.value = newEnd;
            } else if (changed === 'end' && end.value) {
                var newStart = parseInt(end.value) - required + 1;
                if (newStart < minYear) {
                    end.value = minYear + required - 1;
                    newStart = minYear;
                }
                start.value = newStart;
            }
        }

        function validateRange() { 
            var start = document.getElementsByName('period1_start')[0].value;
            var end = document.getElementsByName('period1_end')[0].value;
            var interval = document.getElementById('interval-select').value;
            var required = getRequiredRange();
            var errorDiv = document.getElementById('interval-error');
            var minYear = 1970, maxYear = 2020;
            if(start && end && ((parseInt(end) - parseInt(start) + 1) !== required || parseInt(start) < minYear || parseInt(end) > maxYear)) {
                errorDiv.style.display = 'block';
                if (parseInt(start) < minYear || parseInt(end) > maxYear) {
                    errorDiv.innerText = "Years must be between 1970 and 2020.";
                } else {
                    errorDiv.innerText = "For interval '" + interval + "', the time range must be exactly " + required + " year" + (required > 1 ? "s" : "") + ".";
                }
                document.getElementsByName('period1_end')[0].setCustomValidity("Invalid range");
            } else {
                errorDiv.style.display = 'none';
                document.getElementsByName('period1_end')[0].setCustomValidity("");
            }
        }

        function showTimeRangePicker() { 
            var interval = document.getElementById('interval-select').value;
            var picker = document.getElementById('time-range-picker');
            if (interval && interval !== "") {
                picker.style.display = 'block';
            } else {
                picker.style.display = 'none';
            }
        }
        document.addEventListener('DOMContentLoaded', function() {
            var interval = document.getElementById('interval-select');
            showTimeRangePicker();
            interval.addEventListener('change', showTimeRangePicker);

            var start = document.getElementsByName('period1_start')[0];
            var end = document.getElementsByName('period1_end')[0];

            if (start && end && interval) {
                start.addEventListener('input', function() { lockPeriods('start'); validateRange(); });
                end.addEventListener('input', function() { lockPeriods('end'); validateRange(); });
                interval.addEventListener('change', function() { lockPeriods('start'); validateRange(); });
                lockPeriods('start');
                validateRange();
            }
        });
        </script>
        <div id='interval-error' style='color:red;font-weight:bold;display:none;'></div>
        """;

        // Calculate the midpoint to divide the range in half for the two total columns
        int startYear = (period1Start != null && !period1Start.isEmpty()) ? Integer.parseInt(period1Start) : 1970;
        int endYear = (period1End != null && !period1End.isEmpty()) ? Integer.parseInt(period1End) : 2020;
        int midYear = startYear + (endYear - startYear) / 2;

        // Data Table Section

        html += "<div class='data-table-panel'>"
              + "<h3>Results:</h3>"
              + "<table class='station-table'>"
              + "<thead>"
              + "<tr>"
              + "<th>Metric Name</th>"
              + "<th>Total (" + startYear + "-" + midYear + ")</th>"
              + "<th>Total (" + (midYear + 1) + "-" + endYear + ")</th>"
              + "<th>Change (%)</th>"
              + "<th>Metric Trend (Correlation)</th>"
              + "</tr>"
              + "</thead>"
              + "<tbody>";

        // Dynamically generate the first row as the reference metric
        if (refMetric != null && !refMetric.isEmpty()) {
            int total1 = JDBCConnection.getTotalClimate(refMetric, startYear, midYear,refStation); 
            int total2 = JDBCConnection.getTotalClimate(refMetric, midYear + 1, endYear,refStation);
            double change = (double)(total2 - total1) / total1 * 100;




            html += "<tr style='font-weight:bold; background:#eef;'>";
            html += "<td>" + refMetric + "</td>";
            html += "<td>" + total1 + "</td>";
            html += "<td>" + total2 + "</td>";
            html += "<td>" + String.format("%.2f", change) + "%</td>";
            html += "<td>" + "Reference Metric" + "</td>";
            html += "</tr>";
        }

        // Then add the rest of the metrics (excluding the reference metric)
        for (String metric : refMetricList) {
            if (metric.equals(refMetric)) continue;
            int total1 = JDBCConnection.getTotalClimate(metric, startYear, midYear, refStation);
            int total2 = JDBCConnection.getTotalClimate(metric, midYear + 1, endYear, refStation);
            double change = 0.0;
            if (total1 != 0) {
                change = ((double)(total2 - total1) / Math.abs(total1)) * 100.0;
            } else if (total2 != 0) {
                change = 100.0;
            }

            // Correlation logic
            String trend;
            double threshold = 1.0; // Logical threshold for "No Correlation" (e.g., 1%)
            if (Math.abs(change) < threshold) {
                trend = "No Correlation";
            } else if (change > 0) {
                trend = "Positive correlation";
            } else if (change < 0) {
                trend = "Negative correlation";
            } else {
                trend = "No Correlation";
            }

            html += "<tr>";
            html += "<td>" + metric + "</td>";
            html += "<td>" + total1 + "</td>";
            html += "<td>" + total2 + "</td>";
            html += "<td>" + String.format("%.2f", change) + "%</td>";
            html += "<td>" + trend + "</td>";
            html += "</tr>";
        }

        html += "</tbody></table></div>"; 
        html += "</div>"; // close filter-data-panel
        html += "</div>"; // close content

        // Footer and Closing HTML Tags
        html += CommonElements.getFooter();
        html += "</body></html>";

        // Makes Javalin render the webpage
        context.html(html);
    }
}
