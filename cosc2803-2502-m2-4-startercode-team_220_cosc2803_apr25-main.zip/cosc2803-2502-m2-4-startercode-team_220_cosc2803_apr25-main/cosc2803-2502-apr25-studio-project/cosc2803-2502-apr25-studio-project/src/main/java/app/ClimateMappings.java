package app;
import java.util.Map;

/**
 *
 * @author avnotme
 * Made this class so  that the Database and the website can share Natural Language and Column Names.
 * Put this here so that the code is cleaner and easier to read.
 */
public class ClimateMappings {
    public static final Map<String, String[]> METRIC_MAP = Map.ofEntries(
        Map.entry("PrecipQual", new String[]{"Precipitation", "PrecipQual"}),
        Map.entry("EvapQual", new String[]{"Evaporation", "EvapQual"}),
        Map.entry("MaxTempQual", new String[]{"MaxTemp", "MaxTempQual"}),
        Map.entry("MinTempQual", new String[]{"MinTemp", "MinTempQual"}),
        Map.entry("Humid00Qual", new String[]{"Humid00", "Humid00Qual"}),
        Map.entry("Humid03Qual", new String[]{"Humid03", "Humid03Qual"}),
        Map.entry("Humid06Qual", new String[]{"Humid06", "Humid06Qual"}),
        Map.entry("Humid09Qual", new String[]{"Humid09", "Humid09Qual"}),
        Map.entry("Humid12Qual", new String[]{"Humid12", "Humid12Qual"}),
        Map.entry("Humid15Qual", new String[]{"Humid15", "Humid15Qual"}),
        Map.entry("Humid18Qual", new String[]{"Humid18", "Humid18Qual"}),
        Map.entry("Humid21Qual", new String[]{"Humid21", "Humid21Qual"}),
        Map.entry("SunshineQual", new String[]{"Sunshine", "SunshineQual"}),
        Map.entry("Okta00Qual", new String[]{"Okta00", "Okta00Qual"}),
        Map.entry("Okta03Qual", new String[]{"Okta03", "Okta03Qual"}),
        Map.entry("Okta06Qual", new String[]{"Okta06", "Okta06Qual"}),
        Map.entry("Okta09Qual", new String[]{"Okta09", "Okta09Qual"}),
        Map.entry("Okta12Qual", new String[]{"Okta12", "Okta12Qual"}),
        Map.entry("Okta15Qual", new String[]{"Okta15", "Okta15Qual"}),
        Map.entry("Okta18Qual", new String[]{"Okta18", "Okta18Qual"}),
        Map.entry("Okta21Qual", new String[]{"Okta21", "Okta21Qual"})
    );
        public static final Map<String, String[]> METRIC_MAP2 = Map.ofEntries(
    Map.entry("Daily Rainfall", new String[]{"Precipitation", "PrecipQual"}),
    Map.entry("Consecutive Rainy Days", new String[]{"RainDaysNum"}),
    Map.entry("Accumulated Days Rain", new String[]{"AccumRainDays"}),
    Map.entry("Evaporation", new String[]{"Evaporation", "EvapQual"}),
    Map.entry("Accumulated Days Evap", new String[]{"AccumEvapDays"}),
    Map.entry("Maximum Temperature", new String[]{"MaxTemp", "MaxTempQual"}),
    Map.entry("Accumulated Days MaxTemp", new String[]{"AccumMaxTempDays"}),
    Map.entry("Minimum Temperature", new String[]{"MinTemp", "MinTempQual"}),
    Map.entry("Accumulated Days MinTemp", new String[]{"AccumMinTempDays"}),
    Map.entry("Humidity at 00", new String[]{"Humid00", "Humid00Qual"}),
    Map.entry("Humidity at 03", new String[]{"Humid03", "Humid03Qual"}),
    Map.entry("Humidity at 06", new String[]{"Humid06", "Humid06Qual"}),
    Map.entry("Humidity at 09", new String[]{"Humid09", "Humid09Qual"}),
    Map.entry("Humidity at 12", new String[]{"Humid12", "Humid12Qual"}),
    Map.entry("Humidity at 15", new String[]{"Humid15", "Humid15Qual"}),
    Map.entry("Humidity at 18", new String[]{"Humid18", "Humid18Qual"}),
    Map.entry("Humidity at 21", new String[]{"Humid21", "Humid21Qual"}),
    Map.entry("Sunshine", new String[]{"Sunshine", "SunshineQual"}),
    Map.entry("Cloud Cover at 00", new String[]{"Okta00", "Okta00Qual"}),
    Map.entry("Cloud Cover at 03", new String[]{"Okta03", "Okta03Qual"}),
    Map.entry("Cloud Cover at 06", new String[]{"Okta06", "Okta06Qual"}),
    Map.entry("Cloud Cover at 09", new String[]{"Okta09", "Okta09Qual"}),
    Map.entry("Cloud Cover at 12", new String[]{"Okta12", "Okta12Qual"}),
    Map.entry("Cloud Cover at 15", new String[]{"Okta15", "Okta15Qual"}),
    Map.entry("Cloud Cover at 18", new String[]{"Okta18", "Okta18Qual"}),
    Map.entry("Cloud Cover at 21", new String[]{"Okta21", "Okta21Qual"})
    );
}


