package app;


public class FLAG {
   private String flag;

   private String description;
      

   public FLAG( String flag, String description ) {
       this.flag = flag;
       this.description = description;
   }

  
   public String getFlag() {
      return flag;
   }

   public String getDescription() {
      return description;
   }
}
