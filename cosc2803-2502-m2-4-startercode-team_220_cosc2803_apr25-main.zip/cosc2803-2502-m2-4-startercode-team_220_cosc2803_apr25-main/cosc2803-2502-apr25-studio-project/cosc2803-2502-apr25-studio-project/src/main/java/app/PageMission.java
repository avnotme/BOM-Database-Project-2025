package app;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.sql.*;
import java.util.*;

public class PageMission implements Handler {

    public static final String URL = "/mission.html";

    @Override
    public void handle(Context context) throws Exception {
        StringBuilder html = new StringBuilder("""
    <!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <title>Our Mission</title>
        <link rel='stylesheet' href='common.css'>
        <link rel='stylesheet' href='CommonElements.css'>
        <link rel='stylesheet' href='OurMission.css'>
        <link rel='stylesheet' href='Homepage.css'>
    </head>
    <body><main>
    """);

        html.append(CommonElements.getProgressBar());
        html.append(CommonElements.getNavbar());
        html.append(CommonElements.getHeader());

        // Data highlights and other sections
        html.append("""
<section class="hero">
    <h2>Our Mission</h2>
    <p>
        We empower Australians with the tools and knowledge to understand climate change.
        By transforming complex climate data into accessible insights, our platform serves
        researchers, educators, policymakers, and the public.
    </p>
</section>
""");

        // Get most recent year and averages
        String latestYear = "-";
        String avgPrecip = "-", avgMax = "-", avgMin = "-";
        List<Map<String, String>> personas = new ArrayList<>();
        List<Map<String, String>> team = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db");
             Statement stmt = conn.createStatement()) {

            // Most recent year
            ResultSet yearRs = stmt.executeQuery("""
                SELECT MAX(SUBSTR(DMY, -4)) as latestYear
                FROM ClimateData
                WHERE Precipitation IS NOT NULL AND MaxTemp IS NOT NULL AND MinTemp IS NOT NULL
            """);
            if (yearRs.next()) {
                latestYear = yearRs.getString("latestYear");
                PreparedStatement ps = conn.prepareStatement("""
                    SELECT AVG(Precipitation) AS avgPrecip,
                           AVG(MaxTemp) AS avgMax,
                           AVG(MinTemp) AS avgMin
                    FROM ClimateData
                    WHERE SUBSTR(DMY, -4) = ?
                """);
                ps.setString(1, latestYear);
                ResultSet getStat = ps.executeQuery();
                if (getStat.next()) {
                    avgPrecip = String.format("%.1f", getStat.getDouble("avgPrecip"));
                    avgMax = String.format("%.1f", getStat.getDouble("avgMax"));
                    avgMin = String.format("%.1f", getStat.getDouble("avgMin"));
                }
            }

            // Load the personas
            ResultSet getPersona = stmt.executeQuery("SELECT * FROM Personas");
            while (getPersona.next()) {
                Map<String, String> p = new HashMap<>();
                p.put("Name", getPersona.getString("Name"));
                p.put("Age", getPersona.getString("Age"));
                p.put("Location", getPersona.getString("Location"));
                p.put("Occupation", getPersona.getString("Occupation"));
                p.put("Tech", getPersona.getString("Tech Affinity"));
                p.put("Education", getPersona.getString("Education"));
                p.put("Family", getPersona.getString("Family"));
                personas.add(p);
            }

            // Load the team
            ResultSet getTeam = stmt.executeQuery("SELECT * FROM Team");
            while (getTeam.next()) {
                Map<String, String> t = new HashMap<>();
                t.put("Name", getTeam.getString("Name"));
                t.put("ID", getTeam.getString("Student ID"));
                t.put("Subtask", getTeam.getString("Subtask"));
                team.add(t);
            }

        } catch (SQLException e) {
            html.append("<p style='color:red;'>Error loading data: ").append(e.getMessage()).append("</p>");
        }

        // Data Highlights
        html.append(String.format("""
<section class="data-highlights">
    <h2>Mini-Climate Highlight for %s</h2>
    <h3>Curious about our data? Here's a glimpse!</h3>
    <div class="card-container">
        <div class="data-card">
            <h3>Average Rainfall</h3>
            <p class="data-value">%s mm</p>
            <a href="/page2B.html?metric=Precipitation">View Details</a>
        </div>
        <div class="data-card">
            <h3>Average Max Temp</h3>
            <p class="data-value">%s °C</p>
            <a href="/page2B.html?metric=MaxTemp">View Details</a>
        </div>
        <div class="data-card">
            <h3>Average Min Temp</h3>
            <p class="data-value">%s °C</p>
            <a href="/page2B.html?metric=MinTemp">View Details</a>
        </div>
        <br>
    </div>
</section>
""", latestYear, avgPrecip, avgMax, avgMin));

        // Get selected persona from query parameter
        String selectedPersona = context.queryParam("persona");
        if (selectedPersona == null || selectedPersona.isEmpty()) {
            selectedPersona = "all-personas";
        }

        // Load personas from DB
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db");
             Statement stmt = conn.createStatement()) {
            ResultSet getPersona = stmt.executeQuery("SELECT * FROM Personas");
            while (getPersona.next()) {
                Map<String, String> p = new HashMap<>();
                p.put("Name", getPersona.getString("Name"));
                p.put("Age", getPersona.getString("Age"));
                p.put("Location", getPersona.getString("Location"));
                p.put("Occupation", getPersona.getString("Occupation"));
                p.put("Tech", getPersona.getString("Tech Affinity"));
                p.put("Education", getPersona.getString("Education"));
                p.put("Family", getPersona.getString("Family"));
                personas.add(p);
            }
        } catch (SQLException e) {
            html.append("<p style='color:red;'>Error loading data: ").append(e.getMessage()).append("</p>");
        }

        // Persona bar
        html.append("<section class='persona-hero'><h2>Who We Serve</h2>");
        html.append(Personas.getPersonasBar(selectedPersona)); // Pass selected persona

        // Only this container for AJAX
        html.append("<div id='persona-block-container'></div>");
        if ("all-personas".equals(selectedPersona)) {
            html.append("""
    <script>
    window.addEventListener('DOMContentLoaded', function() {
        fetch('/persona-block?name=all-personas')
            .then(res => res.text())
            .then(html => {
                document.getElementById('persona-block-container').innerHTML = html;
            });
    });
    </script>
    """);
        }
        html.append("</section>");

        // Display team members
        html.append("<section class='personas'><h2>Team Members</h2><div class='persona-grid'>");
        for (Map<String, String> t : team) {
            html.append("<div class='persona-card'>")
                .append("<h3>").append(t.get("Name")).append("</h3>")
                .append("<p><strong>Student ID:</strong> ").append(t.get("ID")).append("</p>")
                .append("<p><strong>Subtask:</strong> ").append(t.get("Subtask")).append("</p>")
                .append("</div>");
        }
        html.append("</div></section>");


        html.append(CommonElements.getFooter());
        html.append("</main></body></html>");
        context.html(html.toString());
    }
}
