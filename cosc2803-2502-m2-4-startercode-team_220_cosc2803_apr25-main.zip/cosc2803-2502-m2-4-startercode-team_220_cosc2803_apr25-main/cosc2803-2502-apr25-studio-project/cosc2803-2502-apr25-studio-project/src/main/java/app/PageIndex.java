package app;

import java.util.ArrayList;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PageIndex implements Handler {

    public static final String URL = "/";

    @Override
    public void handle(Context context) throws Exception {
        String dbPath = "cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        String selectedYear = context.formParam("year");
        if (selectedYear == null || selectedYear.isEmpty()) {
            selectedYear = "2020";
        }
        String sortBy = context.formParam("sort");
        if (sortBy == null || sortBy.isEmpty()) {
            sortBy = "name"; 
}


        String coldestStation = "-", coldestStationName = "-", coldestStationState = "-";
        double coldestTemp = 999;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            Statement stmt = conn.createStatement();
            String sql = """
                SELECT l.Name, l.State, c.MinTemp
                FROM ClimateData c
                JOIN Location l ON c.Site = l.Site
                WHERE c.MinTemp IS NOT NULL
                ORDER BY c.MinTemp ASC LIMIT 1
            """;
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                coldestStationName = rs.getString("Name");
                coldestStationState = rs.getString("State");
                coldestTemp = rs.getDouble("MinTemp");
                coldestStation = coldestStationName + " (" + coldestStationState + ")";
            }
        } catch (SQLException e) {
            coldestStation = "Error loading";
        }

        String hottestStation = "-", hottestStationName = "-", hottestStationState = "-";
        double hottestTemp = -1;
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            Statement stmt = conn.createStatement();
            String sql = """
               SELECT L.Site, L.Name, L.State, L.Region, CD.MaxTemp, CD.Date
                FROM ClimateData CD
                JOIN Location L ON CD.Site = L.Site
                WHERE CD.MaxTemp = (
                    SELECT MAX(CAST(MaxTemp AS REAL)) FROM ClimateData
                    WHERE MaxTemp IS NOT NULL AND MaxTemp != ''
                )
                LIMIT 1;
                """;
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                hottestStationName = rs.getString("Name");
                hottestStationState = rs.getString("State");
                hottestTemp = rs.getDouble("MaxTemp");
                hottestStation = hottestStationName + " (" + hottestStationState + ")";
            }
        } catch (SQLException e) {
            hottestStation = "Error loading";
        }

        String minYear = "1970", maxYear = "2020"; 
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            Statement stmt = conn.createStatement();
            String sql = "SELECT MIN(Year) as minY, MAX(Year) as maxY FROM DateTime";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                minYear = rs.getString("minY");
                maxYear = "2020";
            }
        } catch (SQLException e) {
            minYear = maxYear = "Error";
        }


        ArrayList<String> stationRows = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath)) {
            Statement stmt = conn.createStatement();
            String baseSql = """
                SELECT l.Name, l.State, MIN(c.MinTemp) as ColdestTemp, SUM(c.Precipitation) as TotalRain
                FROM ClimateData c
                JOIN Location l ON c.Site = l.Site
                JOIN DateTime d ON c.Date = d.Date
                WHERE d.Year = ?
                GROUP BY l.Name, l.State
                 """;
            String orderClause = switch (sortBy) {
            case "state" -> " ORDER BY l.State, l.Name";
            case "rainfall" -> " ORDER BY TotalRain DESC";
            case "coldest" -> " ORDER BY ColdestTemp ASC";
            default -> " ORDER BY l.Name";
          };

            String sql = baseSql + orderClause;
            var pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, selectedYear);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("Name");
                String state = rs.getString("State");
                String coldest = rs.getString("ColdestTemp");
                String rain = rs.getString("TotalRain");
                stationRows.add("<tr><td>" + name + "</td><td>" + state + "</td><td>" + (coldest == null ? "-" : coldest) + "</td><td>" + (rain == null ? "-" : rain) + "</td></tr>");
            }
        } catch (SQLException e) {
            stationRows.add("<tr><td colspan='4'>Error loading stations: " + e.getMessage() + "</td></tr>");
        }

        String html = "<html><head><meta charset='UTF-8'><title>FactClimate</title>";
        html += "<link rel='stylesheet' type='text/css' href='common.css' />";
        html += "<link rel='stylesheet' type='text/css' href='Homepage.css' />";
        html = html + "<link rel = 'stylesheet' type  = 'text/css' href = 'CommonElements.css' />";
        html += "</head><body><main>";
        html += CommonElements.getProgressBar();
        html += CommonElements.getNavbar()  + CommonElements.getHeader();

        html += """
       <section class='hero'>
    <h2>Explore Australia's Everchanging Climate And The World Around You</h2>
    <p>
        Curious about how human activities are influencing Australia's climate? Our web application offers you a clear, unbiased look at over 50 years of climate data (1970–2020) straight from the Australian Bureau of Meteorology. Discover fascinating trends in temperature, rainfall, evaporation, cloud cover, and more, all at your fingertips.
    </p>
    <p>
        No matter if you're a concerned individual, a student of the environment, or someone making crucial policy decisions, our easy-to-use tools are designed for you. Visualize climate patterns, compare different weather stations, and unlock meaningful insights that empower you to make well-informed choices.
    </p>

    <h3>Dive Deeper with Our Tools:</h3>
    <ul>
        <li><strong>Weather Station Comparison:</strong> Quickly find and compare stations that show similar climate trends over any period you choose.</li>
        <li><strong>Climate Metric Explorer:</strong> Get a detailed view of changes in important climate metrics like temperature, rainfall, and sunshine across various regions and times.</li>
        <li><strong>Data Quality Insights:</strong> Understand the reliability of the data by investigating quality flags and anomalies.</li>
        <li><strong>Powerful Visualizations:</strong> Our interactive charts and tables help you effortlessly see the broader trends or zoom in on the details.</li>
    </ul>
</section>
        """;

        html += "<div class='cards-row'>"
        + "<div class='card'>"
        + "<img src='coldest.png' class='card-icon' alt='Coldest Icon'/>"
        + "<h3>Coldest Station</h3>"
        + "<p>Station: " + coldestStation + "</p>"
        + "<p>Record low: " + (coldestTemp == 999 ? "-" : coldestTemp + "°C") + "</p>"
        + "</div>"
        + "<div class='card'>"
        + "<img src='hottest.png' class='card-icon' alt='Hottest Icon'/>"
        + "<h3>Hottest Station</h3>"
        + "<p>Station: " + hottestStation + "</p>"
        + "<p>Highest Temperature Recorded: " + (hottestTemp == -1 ? "-" : hottestTemp + "°C") + "</p>"
        + "</div>"
        + "<div class='card'>"
        + "<img src='graph.png' class='card-icon' alt='Data Coverage Icon'/>"
        + "<h3>Data Coverage</h3>"
        + "<p>" + minYear + " to " + maxYear + "</p>"
        + "</div>"
        + "</div>";

        html += """
        <div style='display:flex;gap:30px;margin:40px 0;'>
            <div style='flex:2;'>
                <h3>Map</h3>
                <img src='AusMap.png' alt='Australia Map' style='width:100%;max-width:500px;border-radius:8px;box-shadow:0 2px 8px #0001;'/>
            </div>
            <div style='flex:3;'>
                <h3>Select A Year (1970 - 2020):</h3>
                <h4>Use this tool to find all avalible weather stations in the dataset for a specific year with Coldest Temp (°C) and Total Rainfall (mm)</h4>
                <form method='post' action='/'>
                    <select name='year' onchange='this.form.submit()'>
        """;

        int minY = 1970, maxY = 2020;
        try {
            minY = Integer.parseInt(minYear);
            maxY = Integer.parseInt(maxYear);
        } catch (NumberFormatException e) {
            minY = 1970;
            maxY = 2020;
        }
        for (int y = minY; y <= maxY; y++) {
            html += "<option value='" + y + "'" + (String.valueOf(y).equals(selectedYear) ? " selected" : "") + ">" + y + "</option>";
        }

html += "</select><br><label>Sort By:</label>";
html += "<select name='sort'>";
html += "<option value='name'" + (sortBy.equals("name") ? " selected" : "") + ">Alphabetical</option>";
html += "<option value='state'" + (sortBy.equals("state") ? " selected" : "") + ">State</option>";
html += "<option value='rainfall'" + (sortBy.equals("rainfall") ? " selected" : "") + ">Rainfall</option>";
html += "<option value='coldest'" + (sortBy.equals("coldest") ? " selected" : "") + ">Coldest Temp</option>";
html += "</select>";
html += "<br><button type='submit'>Apply</button>";
html += "</form>";

        html += """
                    </select>
                </form>
                <table class='station-table' style='margin-top:20px;'>
                    <tr>
                        <th>Weather Station</th>
                        <th>State</th>
                        <th>Coldest Temp (°C)</th>
                        <th>Total Rainfall (mm)</th>
                    </tr>
                """;

        for (int i = 0; i < stationRows.size(); i++) {
            if (i < 5) {
                html += stationRows.get(i);
            } else {
                html += stationRows.get(i).replace("<tr", "<tr class='extra-station-row' style='display:none;'");
            }
        }
        html += "</table>";

        if (stationRows.size() > 5) {
            html += "<button class='show-more-btn' onclick='toggleStations(event)'>Show More</button>";
        }

        html += """
        <script>
        function toggleStations(event) {
            const rows = document.querySelectorAll('.extra-station-row');
            const isShowing = Array.from(rows).some(row => row.style.display === '' || row.style.display === 'table-row');
            if (isShowing) {
                
                rows.forEach(row => row.style.display = 'none');
                event.target.textContent = 'Show More';
            } else {
                
                rows.forEach(row => row.style.display = '');
                event.target.textContent = 'Show Less';
            }
        }
        </script>
        """;

        html += """
            </main>
            <div class='full-width-section'>
                <h3 style='text-align:center;'>More Information about our environment:</h3>
                <div class='cards-row'>
                    <div class='card' onclick="location.href='page2A.html'" style='cursor:pointer;'>
                        <h3>Beginner:</h3>
                        <p>Big Picture Climate Trends</p>
                    </div>
                    <div class='card' onclick="location.href='page2B.html'" style='cursor:pointer;'>
                        <h3>Intermediate:</h3>
                        <p>Detailed View by State or Metric</p>
                    </div>
                    <div class='card' onclick="location.href='page3A.html'" style='cursor:pointer;'>
                        <h3>Expert:</h3>
                        <p>Custom Analytics and Similarity Metrics</p>
                    </div>
                </div>
            </div>
            """;


    
        html += "" + CommonElements.getFooter();

        html += "</body></html>";

        context.contentType("text/html; charset=UTF-8");
        context.result(html);
    }
}
