package app;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import io.javalin.http.Context;
import io.javalin.http.Handler;

/**
 * Example Index HTML class using Javalin
 * <p>
 * Generate a static HTML page using Javalin
 * by writing the raw HTML into a Java String object
 *
 * @author Timothy Wiley, 2023. email: timothy.wiley@rmit.edu.au
 * @author Santha Sumanasekara, 2021. email: santha.sumanasekara@rmit.edu.au
 */
public class PageST2C implements Handler {

    // URL of this page relative to http://localhost:7001/
    public static final String URL = "/page2C.html";

    @Override
    public void handle(Context context) throws Exception {
        // Query Parameters for "Assess Climate Data Quality" Filter
        String refQuality = context.queryParam("ref_quality");
        String refMetric = context.queryParam("ref_metric");
        String periodStart = context.queryParam("period_start");
        String periodEnd = context.queryParam("period_end");
        String refSites = context.queryParam("ref_sites");
        
        // Query Parameters for " Count of Quality Flags and their Proportions"
        String refState = context.queryParam("ref_state");
        String refMetric_2 = context.queryParam("ref_metric_2");
        String periodStart_2 = context.queryParam("period_start_2");
        String periodEnd_2 = context.queryParam("period_end_2");

        // Parse Sites List
        List<String> refSitesList = new ArrayList<>();
        if (refSites != null && !refSites.trim().isEmpty()) {
            for (String s : refSites.split(",")) {
                if (!s.trim().isEmpty()) {
                    refSitesList.add(s.trim());
                }
            }
        }

        // Get Dropdown Data
        List<String> QualityFlags = JDBCConnection.getQualityFlags();
        List<String> allSites = JDBCConnection.getAllSites();
        List<String> States = JDBCConnection.getAllStates();
        Integer[] FlagCount = JDBCConnection.getFlagCount(refState, periodStart_2, periodEnd_2, refMetric_2);

        // HTML Head and Navbar
        String html = "<html>";
        html += "<head>"
             + "<title>Subtask 2.3</title>"
             + "<link rel='stylesheet' type='text/css' href='common.css' />"
            + "<link rel='stylesheet' type='text/css' href='Homepage.css' />"

             + "</head>";
        html += "<body>";
        html += CommonElements.getProgressBar();
        html += CommonElements.getNavbar() + CommonElements.getHeader();

        // Hero Section
        html += """
        <section class='hero'>
            <h2> Climate Data Quality</h2>
            <p>The Quality of the Data recorded is essential when it is being used as the framework for research
            policies and public education.</p>
            <p>This page allows you to filter through the data, using quality flags, metrics and date ranges. </p>
            <p>Using this page you can gain a deeper understanding of the climate data quality across all states and terriroties
            , over time periods.</p>
        </section>
        """;

        // Content and Filter Panel
        {
            html += """
            <div class='content'>
                <div class='main-panel'>
                    <div class='main-info'>
                        <h2>Assess Climate Data Quality</h2>
                        <p>Use this tool to assess Data Quality using filters.</p>
                    </div>
                </div>
                <div class='filter-data-panel'>
                    <div class='filter-controls'>
                        <h3>Filter & Controls Panel</h3>
                        <form method='get' action='/page2C.html'>
                            <label>Reference Flag:</label>
                            <select name='ref_quality' required>
                                <option value=''>Select Reference Flag</option>
            """;

            for (String name : QualityFlags) {
                html += "<option value='" + name + "'" + (name.equals(refQuality) ? " selected" : "") + ">" + name + "</option>";
            }

            html += "</select>"
                + "<br><br>"
                + "<label>Climate Metric:</label>"
                + "<select name='ref_metric'>"
                + "<option value=''>Select Climate Metric</option>";

            for (Map.Entry<String, String[]> entry : ClimateMappings.METRIC_MAP.entrySet()) {
                String colName = entry.getKey();
                String label = entry.getValue()[0] + " Quality";
                html += "<option value='" + colName + "'" + (colName.equals(refMetric) ? " selected" : "") + ">" + label + "</option>";
            }

            html += "</select>"
                + "<br><br>"
                + "<label>Station/s:</label>"
                + "<input type='text' name='ref_sites' list='site-list' value='" + (refSites != null ? refSites : "") + "' placeholder='e.g. STN001,STN002'>"
                + "<datalist id='site-list'>";
            for (String site : allSites) {
                html += "<option value='" + site + "'>";
            }
            html += "</datalist>"
                + "<br><br>"
                + "<label>Period Start:</label>"
                + "<input type='text' name='period_start' value='" + (periodStart != null ? periodStart : "1/01/2000") + "' required>"
                + "<br><br>"
                + "<label>Period End:</label>"
                + "<input type='text' name='period_end' value='" + (periodEnd != null ? periodEnd : "31/12/2020") + "' required>"
                + "<br><br>"
                + "<label>Rows per page:</label>"
                + "<select name='rows_per_page'>"
                + "<option value='10'" + ("10".equals(context.queryParam("rows_per_page")) ? " selected" : "") + ">10</option>"
                + "<option value='25'" + ("25".equals(context.queryParam("rows_per_page")) ? " selected" : "") + ">25</option>"
                + "<option value='50'" + ("50".equals(context.queryParam("rows_per_page")) ? " selected" : "") + ">50</option>"
                + "<option value='100'" + ("100".equals(context.queryParam("rows_per_page")) ? " selected" : "") + ">100</option>"
                + "</select>"
                + "<br><br>"
                + "<button type='submit'>Compare</button>"
                + "<button type='reset'>Cancel</button>"
                + "<a href='/page2C.html' style='margin-left:10px;'><button type='button'>Clear</button></a>"
                + "</form>"
                + "</div>";
        }
        // Data Table Section
        {
            // Translate Natural Language Inputs to Database Columns using ClimateMappings.java 
            String metricCol = null;
            String qualityCol = null;
            if (refMetric != null && ClimateMappings.METRIC_MAP.containsKey(refMetric)) {
                metricCol = ClimateMappings.METRIC_MAP.get(refMetric)[0];
                qualityCol = ClimateMappings.METRIC_MAP.get(refMetric)[1];
            }
            if (refQuality != null && !refQuality.isEmpty()) {
                refQuality = refQuality.substring(0, 1);
            }

            List<List<String>> tableRows = new ArrayList<>();
            if (metricCol != null && !metricCol.isEmpty() && qualityCol != null && !qualityCol.isEmpty()) {
                tableRows = JDBCConnection.getClimateDataRows(metricCol, qualityCol, periodStart, periodEnd, refSitesList, refQuality);
            }

            // Current Page, Default to 1
                int page = 1;
                try {
                    String pageParam = context.queryParam("page");
                    if (pageParam != null) {
                        page = Integer.parseInt(pageParam);
                        if (page < 1) page = 1;
                    }
                } catch (NumberFormatException e) {
                    page = 1;
                }

            // Get max rows per page
                int maxRows = 10;
                try {
                    String rowsParam = context.queryParam("rows_per_page");
                    if (rowsParam != null) {
                        maxRows = Integer.parseInt(rowsParam);
                    }
                } catch (NumberFormatException e) {
                    maxRows = 10;
                }

            // Page Idexing, method from W3 Schools, implemented here by @avnotme
                int startIdx = (page - 1) * maxRows;
                int endIdx = Math.min(startIdx + maxRows, tableRows.size());

            // Next and previous page URLs with existing filters
            
                String nextPageUrl = context.path() + "?";
                nextPageUrl += "ref_quality=" + (refQuality != null ? refQuality : "");
                nextPageUrl += "&ref_metric=" + (refMetric != null ? refMetric : "");
                nextPageUrl += "&period_start=" + (periodStart != null ? periodStart : "");
                nextPageUrl += "&period_end=" + (periodEnd != null ? periodEnd : "");
                nextPageUrl += "&ref_sites=" + (refSites != null ? refSites : "");
                nextPageUrl += "&rows_per_page=" + maxRows;
                nextPageUrl += "&page=" + (page + 1);

                int prevPage = (page > 1) ? (page - 1) : 1;
                String prevPageUrl = context.path() + "?";
                prevPageUrl += "ref_quality=" + (refQuality != null ? refQuality : "");
                prevPageUrl += "&ref_metric=" + (refMetric != null ? refMetric : "");
                prevPageUrl += "&period_start=" + (periodStart != null ? periodStart : "");
                prevPageUrl += "&period_end=" + (periodEnd != null ? periodEnd : "");
                prevPageUrl += "&ref_sites=" + (refSites != null ? refSites : "");
                prevPageUrl += "&rows_per_page=" + maxRows;
                prevPageUrl += "&page=" + prevPage;

            //  Table
                html += "<div class='data-table-panel'>"
                    + "<h3>Results:"
                    + (page > 1 ? "<a href='" + prevPageUrl + "' style='margin-left:20px;'><button type='button'>&lt; Prev Page</button></a>" : "")
                    + "<a href='" + nextPageUrl + "' style='margin-left:10px;'><button type='button'>Next Page &gt;</button></a>"
                    + "<span style='margin-left:20px; font-weight:normal; font-size:0.95em;'>"
                    + (endIdx) + " / " + tableRows.size()
                    + "</span>"
                    + "</h3>"
                    + "<table class='station-table'>"
                    + "<thead>"
                    + "<tr>"
                    + "<th>Station ID</th>"
                    + "<th>Station Name</th>"
                    + "<th>Date</th>"
                    + "<th>" + (refMetric != null ? refMetric : "Metric") + "</th>"
                    + "<th>" + (refMetric != null ? refMetric : "Metric") + " Quality</th>"
                    + "</tr>"
                    + "</thead>"
                    + "<tbody>";

                
                for (int i = startIdx; i < endIdx; i++) {
                    List<String> row = tableRows.get(i);
                    html += "<tr>";
                    for (String cell : row) {
                        html += "<td>" + (cell == null ? "" : cell) + "</td>";
                    }
                    html += "</tr>";
                }

                html += "</tbody></table></div>"; 
                html += "</div>";

        }
        // Content and Filter Panel
        {
            html += """
                <div class='main-panel'>
                    <div class='main-info'>
                        <h2>Count of Quality Flags and their Proportions</h2>
                        <p>Use this tool to investigate the proportion of each level of data quality in each state over a period of time.</p>
                    </div>
                </div>
                <div class='filter-data-panel'>
                    <div class='filter-controls'>
                        <h3>Filter & Controls Panel</h3>
                        <form method='get' action='/page2C.html'>
                            <label>Reference Flag:</label>
                            <select name='ref_state' required>
                                <option value=''>Select State</option>
            """;

            for (String name : States) {
                html += "<option value='" + name + "'" + (name.equals(refState) ? " selected" : "") + ">" + name + "</option>";
            }

            html += "</select>"
                + "<br><br>"
                + "<label>Climate Metric:</label>"
                + "<select name='ref_metric_2'>"
                + "<option value=''>Select Climate Metric</option>";

            for (Map.Entry<String, String[]> entry : ClimateMappings.METRIC_MAP.entrySet()) {
                String colName = entry.getKey();
                String label = entry.getValue()[0] + " Quality";
                html += "<option value='" + colName + "'" + (colName.equals(refMetric_2) ? " selected" : "") + ">" + label + "</option>";
            }

            html += "</select>"
                + "<br><br>"
                + "<label>Period Start:</label>"
                + "<input type='text' name='period_start_2' value='" + (periodStart_2 != null ? periodStart_2 : "1/01/2000") + "' required>"
                + "<br><br>"
                + "<label>Period End:</label>"
                + "<input type='text' name='period_end' value='" + (periodEnd_2 != null ? periodEnd_2 : "31/12/2020") + "' required>"
                + "</select>"
                + "<br><br>"
                + "<button type='submit'>Compare</button>"
                + "<button type='reset'>Cancel</button>"
                + "<a href='/page2C.html' style='margin-left:10px;'><button type='button'>Clear</button></a>"
                + "</form>"
                + "</div>";
        }
        // Flag Count Table Section
        {
            // Translate Natural Language Inputs to Database Columns using ClimateMappings.java 
            String metricCol = null;
            String qualityCol = null;






            //  Table
                html += "<div class='data-table-panel'>"
                    + "<h3>Results:"
                    + "<span style='margin-left:20px; font-weight:normal; font-size:0.95em;'>"
                    + "</span>"
                    + "</h3>"
                    + "<table class='station-table'>"
                    + "<thead>"
                    + "<tr>"
                    + "<th>Flag</th>"
                    + "<th>"
                    + (refMetric_2 != null && ClimateMappings.METRIC_MAP.containsKey(refMetric_2)
                    ? ClimateMappings.METRIC_MAP.get(refMetric_2)[0] + " Quality"
                    : "Metric")
                    + "</th>"
                    + "</tr>"
                    + "</thead>"
                    + "<tbody>";

                String[] flagLabels = {"Y", "N", "W", "S", "I", "X"};
                for (int i = 0; i < FlagCount.length && i < flagLabels.length; i++) {
                    html += "<tr>";
                    html += "<td>" + flagLabels[i] + "</td>";
                    html += "<td>" + FlagCount[i] + "</td>";
                    html += "</tr>";
                }

                html += "</tbody></table></div>"; 

        }



       // Footer and Closing HTML Tags
        html += "</div>";
        html += CommonElements.getFooter();
        html += "</body></html>";

        // Makes Javalin render the webpage
        context.html(html);
    }
}
