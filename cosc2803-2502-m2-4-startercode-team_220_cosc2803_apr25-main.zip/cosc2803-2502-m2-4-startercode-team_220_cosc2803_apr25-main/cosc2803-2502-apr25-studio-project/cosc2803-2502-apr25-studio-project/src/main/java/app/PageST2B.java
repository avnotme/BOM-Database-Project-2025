package app;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.sql.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PageST2B implements Handler {

    public static final String URL = "/page2B.html";

    // Helper to convert yyyy-MM-dd to d/MM/yyyy
    private String toDMY(String isoDate) {
        LocalDate date = LocalDate.parse(isoDate);
        return date.format(DateTimeFormatter.ofPattern("d/MM/yyyy"));
    }

    @Override
    public void handle(Context context) throws Exception {
        // --- 1. Read filter values (with sensible defaults) ---
        String metric = context.queryParam("metric") != null ? context.queryParam("metric") : "Precipitation";
        String stationMinStr = context.queryParam("stationMin") != null ? context.queryParam("stationMin") : "1";
        String stationMaxStr = context.queryParam("stationMax") != null ? context.queryParam("stationMax") : "999999";
        String dateStart = context.queryParam("dateStart") != null ? context.queryParam("dateStart") : "1970-01-01";
        String dateEnd = context.queryParam("dateEnd") != null ? context.queryParam("dateEnd") : "1970-01-03";
        String region = context.queryParam("region") != null ? context.queryParam("region") : "";

        int stationMin = Integer.parseInt(stationMinStr);
        int stationMax = Integer.parseInt(stationMaxStr);

        // Convert date format to match DB (d/MM/yyyy)
        dateStart = toDMY(dateStart);
        dateEnd = toDMY(dateEnd);

        // --- Fix region value to match DB if needed ---
        String regionForDB = region;
        if (region.equals("WA")) regionForDB = "W.A.";
        if (region.equals("SA")) regionForDB = "S.A.";
        if (region.equals("NSW")) regionForDB = "N.S.W.";
        if (region.equals("QLD")) regionForDB = "QLD";
        if (region.equals("VIC")) regionForDB = "VIC";   
        if (region.equals("TAS")) regionForDB = "TAS";  
        if (region.equals("NT")) regionForDB = "N.T.";    
        // Add more mappings as needed

        // --- 2. Build SQL for daily values table ---
        String metricCol = metric.equalsIgnoreCase("Precipitation") ? "Precipitation" :
                           metric.equalsIgnoreCase("MaxTemp") ? "MaxTemp" :
                           metric.equalsIgnoreCase("MinTemp") ? "MinTemp" : "Precipitation";

        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";

        // Join Location to get State and LIMIT results to 100
        String sql = "SELECT c.Site, c.DMY, c." + metricCol + ", l.State FROM ClimateData c " +
                     "JOIN Location l ON c.Site = l.Site " +
                     "WHERE CAST(c.Site AS INTEGER) >= ? AND CAST(c.Site AS INTEGER) <= ? " +
                     "AND c.DMY >= ? AND c.DMY <= ? ";
        if (!region.isEmpty() && !region.equals("All")) {
            sql += "AND l.State = ? ";
        }
        sql += "ORDER BY CAST(c.Site AS INTEGER), c.DMY LIMIT 100"; // Limit to 100 rows

        // --- 3. Query for daily values ---
        ArrayList<String[]> dailyRows = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbPath);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, stationMin);
            stmt.setInt(2, stationMax);
            stmt.setString(3, dateStart);
            stmt.setString(4, dateEnd);
            if (!region.isEmpty() && !region.equals("All")) {
                stmt.setString(5, regionForDB);
            }
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String site = rs.getString("Site");
                String dmy = rs.getString("DMY");
                String val = rs.getString(metricCol);
                String state = rs.getString("State");
                dailyRows.add(new String[]{site, dmy, val, state});
            }
        } catch (SQLException e) {
            dailyRows.add(new String[]{"Error", "Error", e.getMessage(), "Error"});
        }

        // --- 4. Query for state totals ---
        String totalCol = metricCol;
        String sqlTotal = "SELECT l.State, SUM(c." + totalCol + ") as Total " +
                          "FROM ClimateData c JOIN Location l ON c.Site = l.Site " +
                          "WHERE CAST(c.Site AS INTEGER) >= ? AND CAST(c.Site AS INTEGER) <= ? " +
                          "AND c.DMY >= ? AND c.DMY <= ? ";
        if (!region.isEmpty() && !region.equals("All")) {
            sqlTotal += "AND l.State = ? ";
        }
        sqlTotal += "GROUP BY l.State ORDER BY l.State";

        ArrayList<String[]> totalRows = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbPath);
             PreparedStatement stmt = conn.prepareStatement(sqlTotal)) {
            stmt.setInt(1, stationMin);
            stmt.setInt(2, stationMax);
            stmt.setString(3, dateStart);
            stmt.setString(4, dateEnd);
            if (!region.isEmpty() && !region.equals("All")) {
                stmt.setString(5, regionForDB);
            }
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String state = rs.getString("State");
                String total = rs.getString("Total");
                totalRows.add(new String[]{state, total});
            }
        } catch (SQLException e) {
            totalRows.add(new String[]{"Error", e.getMessage()});
        }

        // --- 5. Build HTML ---
        String html = "<html><head><meta charset='UTF-8'><title>Exlpore The Data</title>"
            + "<link rel='stylesheet' type='text/css' href='common.css' />"
            + "<link rel='stylesheet' type='text/css' href='CommonElements.css' />"
            + "<link rel='stylesheet' type='text/css' href='Page2B.css' />"
            + "<link rel='stylesheet' type='text/css' href='Homepage.css' />"
            + "</head><body>"
             + "<main>"
            + CommonElements.getProgressBar()
            + CommonElements.getNavbar()
            + CommonElements.getHeader()

            + "<div class='content'>"
            + "<div class='explore-header'>"
            + "<div class='hero'><h2>Explore Data</h2>"
            + "<p><strong>Explore Data</strong> lets you select a metric along with its value ranges, geographic details, temporal <br> and a measurement filter to find the exact data you are looking for! We hold a big <br> library of historical trends and data organized to be accessible for everybody. </p>"
            + "</div></div>";

        // --- Filter Form ---
        html += """
        <div class='filter-data-panel'>
        <form class="filter-controls" method="get" style="margin-bottom:24px;">
                <h3>Filter Controls:</h3>
            <div class="form-group">
                <label>Climate Metric:</label>
                <select name="metric">
                    <option value="Precipitation" %s>Precipitation</option>
                    <option value="MaxTemp" %s>Max Temperature</option>
                    <option value="MinTemp" %s>Min Temperature</option>
                </select>
            </div>
            <div class="form-group">
                <label>Station ID Range:</label>
                <input type="number" name="stationMin" value="%s" min="1" style="width:80px;"> to
                <input type="number" name="stationMax" value="%s" min="1" style="width:80px;">
            </div>
            <div class="form-group">
                <label>Date Range:</label>
                <input type="date" name="dateStart" value="%s">
                to
                <input type="date" name="dateEnd" value="%s">
            </div>
            <div class="form-group">
                <label>Region/State:</label>
                <select name="region">
                    <option value="All" %s>All</option>
                    <option value="VIC" %s>VIC</option>
                    <option value="WA" %s>WA</option>
                    <option value="NSW" %s>NSW</option>
                    <option value="QLD" %s>QLD</option>
                    <option value="SA" %s>SA</option>
                    <option value="TAS" %s>TAS</option>
                    <option value="NT" %s>NT</option>
                </select>
            </div>
            
            
            <button type="submit">Apply</button>
        </form>
        </div>
        """.formatted(
            metric.equals("Precipitation") ? "selected" : "",
            metric.equals("MaxTemp") ? "selected" : "",
            metric.equals("MinTemp") ? "selected" : "",
            stationMinStr, stationMaxStr,
            context.queryParam("dateStart") != null ? context.queryParam("dateStart") : "1970-01-01",
            context.queryParam("dateEnd") != null ? context.queryParam("dateEnd") : "1970-01-03",
            (region.equals("All") || region.isEmpty()) ? "selected" : "",
            region.equals("VIC") ? "selected" : "",
            region.equals("WA") ? "selected" : "",
            region.equals("NSW") ? "selected" : "",
            region.equals("QLD") ? "selected" : "",
            region.equals("SA") ? "selected" : "",
            region.equals("TAS") ? "selected" : "",
            region.equals("NT") ? "selected" : ""
        );

        // --- Daily Values Table (styled like homepage box) ---
        html += """
        <div class="data-table-panel">
            <table class="station-table" style="margin-top:20px;">
                <tr>
                    <th>Station Id</th>
                    <th>Date</th>
                    <th>%s (mm/°C)</th>
                    <th>State</th>
                </tr>
        """.formatted(
            metric.equals("Precipitation") ? "Precipitation" :
            metric.equals("MaxTemp") ? "Max Temperature" :
            metric.equals("MinTemp") ? "Min Temperature" : metric
        );

        int displayLimit = 20;
        if (dailyRows.isEmpty()) {
            html += "<tr><td colspan='4'>No data found for selected filters.</td></tr>";
        } else {
            for (int i = 0; i < dailyRows.size(); i++) {
                String[] row = dailyRows.get(i);
                // Hide rows after the limit
                String rowClass = (i >= displayLimit) ? " class='extra-row' style='display:none;'" : "";
                html += "<tr" + rowClass + "><td>" + row[0] + "</td><td>" + row[1] + "</td><td>" + (row[2] == null ? "-" : row[2]) + "</td><td>" + row[3] + "</td></tr>";
            }
            if (dailyRows.size() > displayLimit) {
                html += "<tr id='show-more-row'><td colspan='4' style='text-align:center;'><button id='show-more-btn' onclick='showMoreRows()'>Show More</button></td></tr>";
            }
        }
        html += "</table>";

        // Add JS to handle Show More
        html += """
        <script>
        function showMoreRows() {
            document.querySelectorAll('.extra-row').forEach(function(row) {
                row.style.display = '';
            });
            document.getElementById('show-more-row').style.display = 'none';
        }
        </script>
        """;


        // --- State Totals Table (styled) ---
        html += String.format("""
        <table class="station-table" style="margin-top:20px;">
            <tr>
                <th>State</th>
                <th>%s Total (mm/°C)</th>
            </tr>
        """,
            metric.equals("Precipitation") ? "Precipitation" :
            metric.equals("MaxTemp") ? "Max Temperature" :
            metric.equals("MinTemp") ? "Min Temperature" : metric
        );
        if (totalRows.isEmpty()) {
            html += "<tr><td colspan='2'>No totals found.</td></tr>";
        } else {
            for (String[] row : totalRows) {
                html += "<tr><td>" + row[0] + "</td><td>" + (row[1] == null ? "-" : row[1]) + "</td></tr>";
            }
        }
        html += "</table></div>"; // close tables and content

        html += CommonElements.getFooter();
        html += "</body></html>";

        context.contentType("text/html; charset=UTF-8");
        context.html(html);
    }
}
