package app;


public class LGA {
   private int code;

   private String name;

   private int year;

 
   public LGA(int code, String name, int year) {
      this.code = code;
      this.name = name;
      this.year = year;
   }

   public int getCode() {
      return code;
   }

   public String getName() {
      return name;
   }

   public int getYear() {
      return year;
   }
}
