package app;

public class CommonElements {
    public static String getNavbar() {
        return """
            <div class='topnav'> 
                <img src='Logo Header.png' alt='Website logo' height='75'>
                <div class='nav-links'>
                    <a href='/'>Homepage</a>
                    <a href='mission.html'>Our Mission</a>
                    <a href='About.html'>About The Data</a>
                    <a href='page2A.html'>Climate In Your Area</a>
                    <a href='page2B.html'>Explore Data</a>
                    <a href='page2C.html'>Climate Data Quality</a>
                    <a href='page3A.html'>Station Compare</a>
                    <a href='page3B.html'>Sub Task 3.B</a>
                    <a href='page3C.html'>Sub Task 3.C</a>
                </div>
            </div>
        """;
    }

    public static String getProgressBar() {
        return """
            <div id='progress-bar-container' style='width:100%;height:6px;z-index:9999;background:rgb(0, 0, 0);'>
                <div id='progress-bar' style='width:0%;height:100%;background:rgb(0, 255, 102);transition:width 0.4s;'></div>
            </div>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    var bar = document.getElementById('progress-bar');
                    bar.style.width = '0%';
                    setTimeout(function() { bar.style.width = '100%'; }, 100);
                });
                window.addEventListener('load', function() {
                    var bar = document.getElementById('progress-bar');
                    bar.style.width = '100%';
                    setTimeout(function() {
                        bar.parentElement.style.display = 'none';
                    }, 600);
                });
            </script>
        """;
    }

    public static String getFooter() {
        return """
            <footer class='site-footer' style='color:#fff;'>
                <style>
                    .site-footer, .site-footer a, .site-footer h5, .site-footer ul, .site-footer li, .site-footer p {
                        color: #fff !important;
                    }
                    .site-footer a:link, .site-footer a:visited {
                        color: #fff !important;
                        text-decoration: underline;
                    }
                    .site-footer a:hover, .site-footer a:active {
                        color: #b3e5fc !important;
                    }
                    .site-footer h5 {
                        font-size: 1.5em;
                    }
                </style>
                <div style='margin-top:30px;'>
                    <div style='float:left;width:20%;'>
                        <div style='width:178px;height:64px;background:#222;border-radius:8px;margin-bottom:10px;'>
                            <img src='Footer Logo.png' alt='Logo' style='width:100%;height:100%;border-radius:0px;position:relative;top:10px;background:#222;'>
                        </div>
                    </div>
                    <div style='float:left;width:25%;'>
                        <h5>Links</h5>
                        <ul>
                            <li><a href='/'>Home</a></li>
                            <li><a href='page2A.html'>Explore Data</a></li>
                            <li><a href='resources/cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/src/main/resources/COSC2803 S12025 Milestone 2-4 v3-1.pdf' download>Download</a></li>
                            <li><a href='mailto:S4170753@student.rmit.edu.au'>Contact / Feedback</a></li>
                        </ul>
                    </div>
                    <div style='float:left;width:30%;'>
                        <h5>About & Purpose</h5>
                        <ul>
                            <li><a href='About.html'>About This Project</a></li>
                            <li><a href='methodology.html'>Methodology</a></li>
                        </ul>
                    </div>
                    <div style='float:left;width:25%;'>
                        <h5>Data Sources & Credibility</h5>
                        <ul>
                            <li><a href='https://www.bom.gov.au/'>BOM</a></li>
                            <li><a href='references.html'>References</a></li>
                        </ul>
                    </div>
                    <div style='clear:both;'></div>
                    <p style='text-align:center;margin-top:20px;'>&copy; 2025 FactClimate. All rights reserved.</p>
                </div>
            </footer>
        """;
    }

    public static String getHeader() {
        return """
            <div class='header'>
                <h1>
                    <img src='ddd.png' class='top-image' alt='Site Logo' height='75'>
                    FactClimate
                </h1>
            </div>
        """;
    }
}

