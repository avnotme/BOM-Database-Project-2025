package app;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import io.javalin.http.Context;
import io.javalin.http.Handler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PageAbout implements Handler {

    public static final String URL = "/About.html";

    @Override
    public void handle(Context context) throws Exception {
        String html = "<html>";

        html = html + "<head>" + 
               "<title>About The Data</title>";
        html = html + "<link rel='stylesheet' type='text/css' href='common.css' />";
        html = html + "<link rel = 'stylesheet' type  = 'text/css' href = 'CommonElements.css' />";
        html += "<link rel='stylesheet' type='text/css' href='Homepage.css' />";
        html = html + "</head>";

        html = html + "<body>";
        html += "<main>";

        html += CommonElements.getProgressBar();
        html = html + CommonElements.getNavbar()  + CommonElements.getHeader();

    
        html = html + """
           <section class='hero'>
                <h2> About The Data</h2>
                <p>To effectively monitor changes in Australia's climate, it is essential to have observational datasets
                that are both high-quality and consistent over time.</p>
                <p>A consistent climate record is one where all observed variations in climate are attributed solely to
                atmospheric behaviour, rather than external </p>
                <p>factors like changes in location, the exposure of the
                observation site, the type of instruments used, or the methods of measurement.</p>
            </section>
        """;

        List<String> DataTypes = JDBCConnection.getDataTypes();
        List<String> Datasets = JDBCConnection.getDatasetNames();
        String refType = context.queryParam("ref_type");
        String refDataset = context.queryParam("ref_dataset");
        String DatasetDescription = JDBCConnection.getDatasetDescription(refDataset);



        List<String> dataInfo = null;
        List<String> datasetData = null;
        List<String> datasetAttributtesList = null;
        List<String> datasetDescriptionsList = null;
        if (refType != null && !refType.isEmpty()) {
            dataInfo = JDBCConnection.getDataInfo(refType);
        } else {
            dataInfo = List.of("--", "--", "--", "--");
        }
       if(refDataset != null && !refDataset.isEmpty()) {
            datasetData = JDBCConnection.getDatasetDataList(refDataset);
            datasetAttributtesList = JDBCConnection.getDatasetAttributesList(refDataset);
            datasetDescriptionsList = JDBCConnection.getDatasetDescriptionsList(refDataset);
        } else {
            datasetData = List.of("--", "--", "--", "--");
            datasetAttributtesList = List.of("--", "--", "--", "--");
            datasetDescriptionsList = List.of("--", "--", "--", "--");
        }
        

        html += "<div class='content'>"
            + "<div class='main-panel'>"
            + "<div class='main-info' >"
            + "<h2>Find Information about Data Fields</h2>"
            + "<p>Select a Data Type, to know more about its attribute (as recorded in the database), its unit and its overall purpose in determining rate and intensity of climate change.</p>"
            + "</div></div>"
            + "<div class='about-filter-panel'>"
            + "<div class='about-filter-controls'>"
            + "<h3>Filter</h3>"
            + "<form method='get' action='/About.html'>"
            + "<label>Field:</label>"
            + "<select name='ref_type' required>";
        html += "<option value=\"\"" + ((refType == null || refType.isEmpty()) ? " selected" : "") + ">No Selection</option>";

        for (String name : DataTypes) {
            html += "<option value=\"" + name + "\"" + (name.equals(refType) ? " selected" : "") + ">" + name + "</option>";
        }
        html += "</select>"
            + "<br><br>"
            + "<button type='submit'>Search</button>"
            + "<button type='reset'>Cancel</button>"
            + "</form>"
            + "</div>"
            + "<div class='about-output-boxes'>"
            + "<div class='about-output-box'>"
            + "<div class='about-output-title'>Database Label</div>"
            + "<div class='about-output-value'>" + dataInfo.get(1) + "</div>"
            + "</div>"
            + "<div class='about-output-box'>"
            + "<div class='about-output-title'>Unit</div>"
            + "<div class='about-output-value'>" + dataInfo.get(2) + "</div>"
            + "</div>"
            + "<div class='about-output-box'>"
            + "<div class='about-output-title'>Description</div>"
            + "<div class='about-output-value'>" + dataInfo.get(0) + "</div>"
            + "</div>"
            + "<div class='about-output-box'>"
            + "<div class='about-output-title'>Purpose</div>"
            + "<div class='about-output-value'>" + dataInfo.get(3) + "</div>"
            + "</div>"
            + "</div>" 
            + "</div>" 






            + "<div class='main-panel'>"
            + "<div class='main-info' >"
            + "<h2>Find Information about Datasets</h2>"
            + "<p>Select a Dataset, to know more about the attributes used in the dataset. </p>"
            + "</div></div>"
            + "<div class='about-filter-panel'>"
            + "<div class='about-filter-controls'>"
            + "<h3>Filter</h3>"
            + "<form method='get' action='/About.html'>"
            + "<label>Field:</label>"
            + "<select name='ref_dataset' required>";
        html += "<option value=\"\"" + ((refDataset == null || refDataset.isEmpty()) ? " selected" : "") + ">No Selection</option>";

        for (String name : Datasets) {
            html += "<option value=\"" + name + "\"" + (name.equals(refDataset) ? " selected" : "") + ">" + name + "</option>";
        }
        html += "</select>"
            + "<br><br>"
            + "<button type='submit'>Search</button>"
            + "<button type='reset'>Cancel</button>"
            + "</form>"
            + "</div>"

            + "<div class='about-output-boxes'>"
            + "<div class='about-output-box'>"
            + "<div class='about-output-title'>Database Label</div>"
            + "<div class='about-output-value'>" + DatasetDescription + "</div>"
            + "</div>"
            + "</div>" 
            + "</div>"; 

        html += "<div class='about-output-table' style='margin-top:20px;'>";
        html += "<table class='station-table'>";
        html += "<tr><th>Attribute</th><th>Value</th><th>Description</th></tr>";
        for (int i = 0; i < datasetData.size(); i++) {
            String attr = (datasetAttributtesList.size() > i) ? datasetAttributtesList.get(i) : "--";
            String val = (datasetData.size() > i) ? datasetData.get(i) : "--";
            String desc = (datasetDescriptionsList.size() > i) ? datasetDescriptionsList.get(i) : "--";
            html += "<tr><td>" + attr + "</td><td>" + val + "</td><td>" + desc + "</td></tr>";
        }
        html += "</table></div>";






            

        html += "</div></div></div>"; 









        html += CommonElements.getFooter(); 
        html += "</body></html>";

        context.contentType("text/html; charset=UTF-8");
        context.result(html);
    }
    
}