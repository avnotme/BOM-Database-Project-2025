package app;

import io.javalin.http.Context;
import io.javalin.http.Handler;
import java.sql.*;
import java.util.Arrays;
// import java.util.Map; // Not directly needed for this file, keeping imports lean

public class PageST3B implements Handler {

    public static final String URL = "/page3B.html";
    private int parseOrDefault(String val, int def) {
        try {
            return (val != null && !val.isEmpty()) ? Integer.parseInt(val) : def;
        } catch (Exception e) {
            return def;
        }
    }

    @Override
    public void handle(Context context) throws Exception {
        
        int period1Start = parseOrDefault(context.queryParam("period1_start"), 2005);
        int period1End = parseOrDefault(context.queryParam("period1_end"), 2009);
        int period2Start = parseOrDefault(context.queryParam("period2_start"), 2010);
        int period2End = parseOrDefault(context.queryParam("period2_end"), 2015);
        String refMetric = context.queryParam("ref_metric");
        if (refMetric == null || refMetric.isEmpty()) refMetric = "Precipitation"; 

       
        String html = "<html>";
        html += "<head>"
             + "<title>Climate Metric Similarity</title>"
             + "<link rel='stylesheet' type='text/css' href='common.css' />"
             + "<link rel='stylesheet' type='text/css' href='Homepage.css' />" 
             + "</head>";
        html += "<body>";
        html += CommonElements.getProgressBar();
        html += CommonElements.getNavbar() + CommonElements.getHeader();

        
        html += """
        <section class='hero'>
            <h2> Climate Metric Similarity Over Periods</h2>
            <p>This tool allows you to compare climate metrics (Precipitation, Evaporation, Max Temperature) across two distinct time periods.</p>
            <p>Select your desired periods and a reference metric to see percentage changes and differences from the reference.</p>
        </section>
        """;

        
        html += "<div class='content'>";

        html += """
            <div class='main-panel'>
                <div class='main-info'>
                    <h2>Compare Climate Metric Trends</h2>
                    <p>Enter two different periods to analyze the change in selected climate metrics.</p>
                    <p>The table below will show the total or average for each metric in both periods, the percentage change, and how far each metric's change deviates from your chosen reference metric.</p>
                </div>
            </div>
            """;

        html += "<div class='filter-data-panel'>";
        html += "<div class='filter-controls'>";
        html += "<h3>Comparison Controls</h3>";
        html += "<form method='get' action='/page3B.html'>";

        html += "<label>Period 1 Start Year:</label>";
        html += "<input type='number' name='period1_start' min='1900' max='2100' value='" + period1Start + "' required>";
        html += "<br><br>";
        html += "<label>Period 1 End Year:</label>";
        html += "<input type='number' name='period1_end' min='1900' max='2100' value='" + period1End + "' required>";
        html += "<br><br>";
        html += "<label>Period 2 Start Year:</label>";
        html += "<input type='number' name='period2_start' min='1900' max='2100' value='" + period2Start + "' required>";
        html += "<br><br>";
        html += "<label>Period 2 End Year:</label>";
        html += "<input type='number' name='period2_end' min='1900' max='2100' value='" + period2End + "' required>";
        html += "<br><br>";
        html += "<label>Reference Metric:</label>";
        html += "<select name='ref_metric'>";
        html += "<option value='Precipitation'" + ("Precipitation".equals(refMetric) ? " selected" : "") + ">Precipitation</option>";
        html += "<option value='Evaporation'" + ("Evaporation".equals(refMetric) ? " selected" : "") + ">Evaporation</option>";
        html += "<option value='MaxTemp'" + ("MaxTemp".equals(refMetric) ? " selected" : "") + ">Max Temperature</option>";
        html += "</select>";
        html += "<br><br>";
        html += "<button type='submit'>Compare</button>";
        html += "<button type='reset'>Reset</button>";
        html += "<a href='/page3B.html' style='margin-left:10px;'><button type='button'>Clear</button></a>";
        html += "</form>";
        html += "</div>"; // End filter-controls
        html += "</div>"; // End filter-data-panel


        // Data Table Section (adapted from PageST2C's data-table-panel)
        html += "<div class='data-table-panel'>";
        html += "<h3>Comparison Results</h3>";
        html += "<table class='station-table'>"; // Reusing station-table class for consistency
        html += "<thead>";
        html += "<tr>";
        html += "<th>Metric Name</th>";
        html += "<th>Total (" + period1Start + "-" + period1End + ")</th>";
        html += "<th>Total (" + period2Start + "-" + period2End + ")</th>";
        html += "<th>% Change</th>";
        html += "<th>Difference from Reference (%)</th>";
        html += "</tr>";
        html += "</thead>";
        html += "<tbody>";

        
        double p1_precip = 0, p2_precip = 0, p1_evap = 0, p2_evap = 0, p1_temp = 0, p2_temp = 0;
        boolean hasData = false;
        
        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
            
            String sql = "SELECT " +
                "SUM(CASE WHEN year BETWEEN ? AND ? THEN Precipitation ELSE 0 END) AS period1_precip, " +
                "SUM(CASE WHEN year BETWEEN ? AND ? THEN Precipitation ELSE 0 END) AS period2_precip, " +
                "SUM(CASE WHEN year BETWEEN ? AND ? THEN Evaporation ELSE 0 END) AS period1_evap, " +
                "SUM(CASE WHEN year BETWEEN ? AND ? THEN Evaporation ELSE 0 END) AS period2_evap, " +
                "AVG(CASE WHEN year BETWEEN ? AND ? THEN MaxTemp ELSE NULL END) AS period1_maxtemp, " +
                "AVG(CASE WHEN year BETWEEN ? AND ? THEN MaxTemp ELSE NULL END) AS period2_maxtemp " +
                "FROM (SELECT CASE WHEN CAST(SUBSTR(Date, -2) AS INT) < 50 THEN 2000 + CAST(SUBSTR(Date, -2) AS INT) ELSE 1900 + CAST(SUBSTR(Date, -2) AS INT) END AS year, " +
                "Precipitation, Evaporation, MaxTemp FROM ClimateData WHERE Precipitation IS NOT NULL AND Evaporation IS NOT NULL AND MaxTemp IS NOT NULL)";
            PreparedStatement ps = conn.prepareStatement(sql);

          
            ps.setInt(1, period1Start);
            ps.setInt(2, period1End);
            ps.setInt(3, period2Start);
            ps.setInt(4, period2End);
            ps.setInt(5, period1Start);
            ps.setInt(6, period1End);
            ps.setInt(7, period2Start);
            ps.setInt(8, period2End);
            ps.setInt(9, period1Start);
            ps.setInt(10, period1End);
            ps.setInt(11, period2Start);
            ps.setInt(12, period2End);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                hasData = true;
                p1_precip = rs.getDouble("period1_precip");
                p2_precip = rs.getDouble("period2_precip");
                p1_evap = rs.getDouble("period1_evap");
                p2_evap = rs.getDouble("period2_evap");
                p1_temp = rs.getDouble("period1_maxtemp");
                p2_temp = rs.getDouble("period2_maxtemp");
            }
        } catch (SQLException e) {
            html += "<tr><td colspan='5'>Error loading data: " + e.getMessage() + "</td></tr>";
            System.err.println("Database connection or query error in PageST3B: " + e.getMessage());
            e.printStackTrace();
        }

        // Calculate % change
        class MetricRow {
            String name;
            double p1, p2, pct, diff;
            MetricRow(String n, double a, double b, double c, double d) { name=n; p1=a; p2=b; pct=c; diff=d; }
        }
        MetricRow[] rows = new MetricRow[3];
        if (hasData) {
            double pct_precip = (p1_precip != 0) ? ((p2_precip - p1_precip) * 100.0 / p1_precip) : 0;
            double pct_evap = (p1_evap != 0) ? ((p2_evap - p1_evap) * 100.0 / p1_evap) : 0;
            double pct_temp = (p1_temp != 0) ? ((p2_temp - p1_temp) * 100.0 / p1_temp) : 0;
            double refPct = switch (refMetric) {
                case "Precipitation" -> pct_precip;
                case "Evaporation" -> pct_evap;
                case "MaxTemp" -> pct_temp;
                default -> pct_precip; 
            };
            rows[0] = new MetricRow("Precipitation", p1_precip, p2_precip, pct_precip, pct_precip - refPct);
            rows[1] = new MetricRow("Evaporation", p1_evap, p2_evap, pct_evap, pct_evap - refPct);
            rows[2] = new MetricRow("Max Temperature", p1_temp, p2_temp, pct_temp, pct_temp - refPct);

            final String refMetricFinal = refMetric;

            Arrays.sort(rows, (a, b) -> {
                if (a.name.replace(" ", "").equalsIgnoreCase(refMetricFinal)) return -1;
                if (b.name.replace(" ", "").equalsIgnoreCase(refMetricFinal)) return 1;
                return Double.compare(Math.abs(a.diff), Math.abs(b.diff));
            });

            for (MetricRow row : rows) {
                String rowNameForComparison = row.name.replace(" ", ""); // Remove spaces for comparison with refMetric "MaxTemp" vs "Max Temperature"
                boolean isRef = rowNameForComparison.equalsIgnoreCase(refMetricFinal);

                html += "<tr" + (isRef ? " class='highlight'" : "") + ">";
                html += "<td>" + row.name + "</td>";
                html += "<td>" + String.format("%.2f", row.p1) + "</td>";
                html += "<td>" + String.format("%.2f", row.p2) + "</td>";
                html += "<td>" + String.format("%+.2f%%", row.pct) + "</td>";
                html += isRef
                    ? "<td>0.00% (selected)</td>"
                    : "<td>" + String.format("%+.2f%%", row.diff) + "</td>";
                html += "</tr>";
            }
        } else {
            html += "<tr><td colspan='5'>No data found for the selected periods. Please try different years.</td></tr>";
        }

        html += "</tbody></table></div>"; 
        html += "</div>"; 

        // Footer and Closing HTML Tags (Copied from PageST2C)
        html += CommonElements.getFooter();
        html += "</body></html>";

        // Makes Javalin render the webpage
        context.html(html);
    }


}