package app;

import io.javalin.http.Context;
import io.javalin.http.Handler;
import java.util.*;
import java.sql.*;

public class PageST3A implements Handler {

    public static final String URL = "/page3A.html";

    @Override
    public void handle(Context context) throws Exception {
        String refStation = context.queryParam("ref_station");
        if (refStation == null || refStation.isEmpty()) {
            refStation = "Melbourne Airport"; 
        }

        String metric = context.queryParam("metric");
        if (metric == null || metric.isEmpty()) {
            metric = "MaxTemp";
        }  
        String periodType = context.queryParam("period_type");
        if (periodType == null || periodType.isEmpty()) {
            periodType = "decade";
        }

        String aggregation = context.queryParam("aggregation");
        if (aggregation == null || aggregation.isEmpty()) {
            aggregation = "decade"; 
        }

        String period1StartStr = context.queryParam("period1_start");
        if (period1StartStr == null || period1StartStr.isEmpty()) {
            period1StartStr = "2000";
        }

        String period1EndStr = context.queryParam("period1_end");
        if (period1EndStr == null || period1EndStr.isEmpty()) {
            period1EndStr = "2009";
        }

        String period2StartStr = context.queryParam("period2_start");
        if (period2StartStr == null || period2StartStr.isEmpty()) {
            period2StartStr = "2010";
        }

        String period2EndStr = context.queryParam("period2_end");
        if (period2EndStr == null || period2EndStr.isEmpty()) {
            period2EndStr = "2019";
        }

        String numStationsStr = context.queryParam("num_stations");
        if (numStationsStr == null || numStationsStr.isEmpty()) {
            numStationsStr = "10";
        }

        int numStations = 10;
        if (numStationsStr != null && !numStationsStr.isEmpty()) {
            try {
                numStations = Integer.parseInt(numStationsStr);
            } catch (NumberFormatException e) {
                numStations = 10;
            }
        }

        int p1Start = 2000, p1End = 2009, p2Start = 2010, p2End = 2019;
        try {
            if (period1StartStr != null && !period1StartStr.isEmpty())
                p1Start = Integer.parseInt(period1StartStr);
        } catch (NumberFormatException ignored) {}
        try {
            if (period1EndStr != null && !period1EndStr.isEmpty())
                p1End = Integer.parseInt(period1EndStr);
        } catch (NumberFormatException ignored) {}
        try {
            if (period2StartStr != null && !period2StartStr.isEmpty())
                p2Start = Integer.parseInt(period2StartStr);
        } catch (NumberFormatException ignored) {}
        try {
            if (period2EndStr != null && !period2EndStr.isEmpty())
                p2End = Integer.parseInt(period2EndStr);
        } catch (NumberFormatException ignored) {}

        if ("decade".equals(periodType)) {
            p1End = p1Start + 9;
            p2End = p2Start + 9;
        } else if ("halfdecade".equals(periodType)) {
            p1End = p1Start + 4;
            p2End = p2Start + 4;
        }

        String labelPeriod1, labelPeriod2;
        if ("decade".equals(aggregation)) {
            labelPeriod1 = (period1StartStr != null && !period1StartStr.isEmpty() ? period1StartStr : "2000") + "s";
            labelPeriod2 = (period2StartStr != null && !period2StartStr.isEmpty() ? period2StartStr : "2010") + "s";
        } else if ("halfdecade".equals(aggregation)) {
            int p1StartLabel = 2000, p2StartLabel = 2005;
            try {
                if (period1StartStr != null && !period1StartStr.isEmpty())
                    p1StartLabel = Integer.parseInt(period1StartStr);
            } catch (NumberFormatException ignored) {}
            try {
                if (period2StartStr != null && !period2StartStr.isEmpty())
                    p2StartLabel = Integer.parseInt(period2StartStr);
            } catch (NumberFormatException ignored) {}
            labelPeriod1 = p1StartLabel + "–" + (p1StartLabel + 4);
            labelPeriod2 = p2StartLabel + "–" + (p2StartLabel + 4);
        } else {
            String p1StartLabel = (period1StartStr != null && !period1StartStr.isEmpty()) ? period1StartStr : "2005";
            String p1EndLabel = (period1EndStr != null && !period1EndStr.isEmpty()) ? period1EndStr : "2009";
            String p2StartLabel = (period2StartStr != null && !period2StartStr.isEmpty()) ? period2StartStr : "2010";
            String p2EndLabel = (period2EndStr != null && !period2EndStr.isEmpty()) ? period2EndStr : "2015";
            labelPeriod1 = p1StartLabel + "–" + p1EndLabel;
            labelPeriod2 = p2StartLabel + "–" + p2EndLabel;
        }


        String html = """
<html>
<head>
    <meta charset='UTF-8'>
    <title>Find Similar Weather Stations</title>
    <link rel='stylesheet' type='text/css' href='common.css' />
    <link rel='stylesheet' type='text/css' href='CommonElements.css' />
    <link rel='stylesheet' type='text/css' href='Homepage.css' />
</head>
<body>
<main>
""" +  CommonElements.getProgressBar() + CommonElements.getNavbar() + CommonElements.getHeader();

        List<String> stationNames = JDBCConnection.getStationsList();
        html += """
<div class='content'>
    <div class='hero'>
        <div class='main-map'>
            <img src='weatherstations.jpg' alt='Globe Map' style='width:320px;height:220px;object-fit:cover;border-radius:8px;box-shadow:0 2px 8px #0001;'/>
        </div>
        
            <h2>Find Similar Weather Stations</h2>
            <p>Use this tool to compare weather stations across different weatherstations based on a climate metric over custom time periods.
                Select a reference station, pick one or more date ranges and choose a climate metric like temperature or rainfall. 
                The tool calculates percentage changes between the periods and finds stations with similar trends. </p>      
             <p><strong>How to use:</strong></p>
            <ul>
                <li><b>Reference Station:</b> Select the station you want to compare others against.</li>
                <li><b>Time Periods:</b> Define one or multiple date ranges to analyse changes over time (e.g., years, decades).</li>
                <li><b>Climate Metric:</b> Choose from temperature, precipitation, evaporation, sunshine and cloud cover.</li>
                <li><b>Number of Stations:</b> Set how many similar stations to display in the results.</li>
                <li><b>Results:</b> Shows % change in the selected metric for each period, and how close other stations are to the reference station’s change.</li>
            </ul>
                
        <div class='main-map'>
            <img src='waethertrend.jpg' alt='Globe Map' style='width:320px;height:220px;object-fit:cover;border-radius:8px;box-shadow:0 2px 8px #0001;'/>
        </div>
    </div>
    <div class='filter-data-panel'>
        <div class='filter-controls'>
            <h3>Filter & Controls Panel</h3>
            <form method='get' action='/page3A.html'>
                <label>Reference Station Selector:</label>
                <select name='ref_station' required>
                    <option value=''>Select Reference Station</option>
""";

         for (String name : stationNames) {
            html += "<option value='" + name + "'" + (name.equals(refStation) ? " selected" : "") + ">" + name + "</option>";
        }

       html += "</select><br><br>"
        + "<label>Time Period Type:</label>"
        + "<select name='period_type'>"
        + "<option value='year'" + ("year".equals(periodType) ? " selected" : "") + ">Year Range</option>"
        + "<option value='decade'" + ("decade".equals(periodType) ? " selected" : "") + ">Decade</option>"
        + "<option value='halfdecade'" + ("halfdecade".equals(periodType) ? " selected" : "") + ">Half-Decade</option>"
        + "</select><br><br>"
        + "<label>Period 1 Start/End:</label>"
        + "<input type='number' name='period1_start' value='" + p1Start + "' required>"
        + "<input type='number' name='period1_end' value='" + p1End + "' required><br><br>"
        + "<label>Period 2 Start/End:</label>"
        + "<input type='number' name='period2_start' value='" + p2Start + "' required>"
        + "<input type='number' name='period2_end' value='" + p2End + "' required><br><br>"
        + "<label>Climate Metric:</label>"
        + "<select name='metric'>"
        + "<option value='AvgTemp'" + ("AvgTemp".equals(metric) ? " selected" : "") + ">Average Temperature</option>"
        + "<option value='MaxTemp'" + ("MaxTemp".equals(metric) ? " selected" : "") + ">Max Temperature</option>"
        + "<option value='MinTemp'" + ("MinTemp".equals(metric) ? " selected" : "") + ">Min Temperature</option>"
        + "<option value='Precipitation'" + ("Precipitation".equals(metric) ? " selected" : "") + ">Rainfall</option>"
        + "<option value='Evaporation'" + ("Evaporation".equals(metric) ? " selected" : "") + ">Evaporation</option>"
        + "<option value='CloudCover'" + ("CloudCover".equals(metric) ? " selected" : "") + ">Cloud Cover</option>"
        + "<option value='Sunshine'" + ("Sunshine".equals(metric) ? " selected" : "") + ">Sunshine</option>"
        + "</select><br><br>"
        + "<label>Number of Stations to Compare:</label>"
        + "<input type='number' name='num_stations' value='" + numStations + "' min='1' max='20'><br><br>"
        + "<button type='submit'>Compare</button> <button type='reset'>Cancel</button>"
        + "</form></div>"
    + "<div class='data-table-panel'>"
    + "<h3>Results:</h3>"
    + "<table class='station-table'>"
    + "<thead>"
    + "<tr>"
    + "<th>Station Name</th>"
    + "<th>" + labelPeriod1 + "</th>"
    + "<th>" + labelPeriod2 + "</th>"
    + "<th>% Change</th>"
    + "<th>Diff from Ref (%)</th>"
    + "<th>Region / State</th>"
    + "</tr>"
    + "</thead>"
    + "<tbody>";

            class StationChange {
            String name, region;
            double avg1, avg2, percentChange, driftFromRef;
            StationChange(String n, String r, double a1, double a2, double pc, double drift) {
                name = n; region = r; avg1 = a1; avg2 = a2; percentChange = pc; driftFromRef = drift;
            }
        }
        List<StationChange> allStations = new ArrayList<>();
        StationChange refStationData = null; 
        String metricCol;
       switch (metric) {
            case "AvgTemp" -> metricCol = null;
            case "MaxTemp" -> metricCol = "MaxTemp";
            case "MinTemp" -> metricCol = "MinTemp";
            case "Precipitation" -> metricCol = "Precipitation";
            case "Evaporation" -> metricCol = "Evaporation";
            case "CloudCover" -> metricCol = "Okta09"; 
            case "Sunshine" -> metricCol = "Sunshine";
            default -> metricCol = "MaxTemp";
        }    
         String metricLabel;
            switch (metric) {
                case "AvgTemp" -> metricLabel = "Average Temp";
                case "MaxTemp" -> metricLabel = "Max Temperature";
                case "MinTemp" -> metricLabel = "Min Temperature";
                case "Precipitation" -> metricLabel = "Rainfall";
                case "Evaporation" -> metricLabel = "Evaporation (mm)";
                case "CloudCover" -> metricLabel = "Cloud Cover (Okta)";
                case "Sunshine" -> metricLabel = "Sunshine Hours";
                default -> metricLabel = "Max Temperature";
            }

        if (refStation != null && !refStation.isEmpty()) {
            try (Connection conn = DriverManager.getConnection("jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db")) {
               String sql;
                sql = "SELECT l.Name, l.Region, " +
                    (metricCol != null ?
                            "AVG(CASE WHEN d.Year BETWEEN ? AND ? THEN c." + metricCol + " END) AS avg1, " +
                            "AVG(CASE WHEN d.Year BETWEEN ? AND ? THEN c." + metricCol + " END) AS avg2 " :
                            "AVG(CASE WHEN d.Year BETWEEN ? AND ? THEN (c.MaxTemp + c.MinTemp)/2.0 END) AS avg1, " +
                            "AVG(CASE WHEN d.Year BETWEEN ? AND ? THEN (c.MaxTemp + c.MinTemp)/2.0 END) AS avg2 ") +
                            "FROM Location l " +
                            "JOIN ClimateData c ON l.Site = c.Site " +
                            "JOIN DateTime d ON c.Date = d.Date " +
                            "GROUP BY l.Name, l.Region";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, p1Start);
                ps.setInt(2, p1End);
                ps.setInt(3, p2Start);
                ps.setInt(4, p2End);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    String name = rs.getString("Name");
                    String region = rs.getString("Region");
                    double avg1 = rs.getDouble("avg1");
                    double avg2 = rs.getDouble("avg2");

                
                    if (rs.wasNull() || Double.isNaN(avg1) || Double.isNaN(avg2)) {
                        continue;
                    }
                    
                    double percentChange = (avg1 != 0) ? ((avg2 - avg1) / avg1) * 100.0 : 0.0;
                    
                    StationChange currentStation = new StationChange(name, region, avg1, avg2, percentChange, 0.0);
                    
                    if (name.equals(refStation)) {
                        refStationData = currentStation;
                    } else {
                        allStations.add(currentStation); 
                    }
                }
            } catch (SQLException e) {
                html += "<tr><td colspan='6'>Error loading data: " + e.getMessage() + "</td></tr>";
            }
        }

        if (refStationData != null) {
            final StationChange finalRefStationData = refStationData; 
            for (StationChange sc : allStations) { 
                sc.driftFromRef = Math.abs(sc.percentChange - finalRefStationData.percentChange);
            }
            allStations.sort(Comparator.comparingDouble(sc -> sc.driftFromRef));
        } else {
 
            allStations.sort(Comparator.comparingDouble(sc -> sc.percentChange));
        }


        if (refStationData != null) {
            html += "<tr style='font-weight:bold;background:#e0f7fa;'>";
            html += "<td>" + refStationData.name + "</td>";
            html += "<td>" + (Double.isNaN(refStationData.avg1) ? "-" : String.format("%.2f", refStationData.avg1)) + "</td>";
            html += "<td>" + (Double.isNaN(refStationData.avg2) ? "-" : String.format("%.2f", refStationData.avg2)) + "</td>";
            html += "<td>" + (Double.isNaN(refStationData.percentChange) ? "-" : String.format("%+.2f%%", refStationData.percentChange)) + "</td>";
            html += "<td>0.00%</td>"; 
            html += "<td>" + refStationData.region + "</td>";
            html += "</tr>";
        }


        int countOtherStationsPrinted = 0;
        for (StationChange sc : allStations) {
            if (countOtherStationsPrinted >= numStations) {
                break;
            }
            
            html += "<tr>";
            html += "<td>" + sc.name + "</td>";
            html += "<td>" + (Double.isNaN(sc.avg1) ? "-" : String.format("%.2f", sc.avg1)) + "</td>";
            html += "<td>" + (Double.isNaN(sc.avg2) ? "-" : String.format("%.2f", sc.avg2)) + "</td>";
            html += "<td>" + (Double.isNaN(sc.percentChange) ? "-" : String.format("%+.2f%%", sc.percentChange)) + "</td>";
            html += "<td>" + (Double.isNaN(sc.driftFromRef) ? "-" : String.format("%.2f%%", sc.driftFromRef)) + "</td>";
            html += "<td>" + sc.region + "</td>";
            html += "</tr>";
            countOtherStationsPrinted++;
        }

        if (refStationData == null && countOtherStationsPrinted == 0) { 
            html += "<tr><td colspan='6'>No data found for the selected filters.</td></tr>";
        }

    
        html += """
            </tbody>
            </table>
        </div>
        </div>
        <div class='trends-panel'>
        <div class='trend-bars'>
            <h3>Visualization Panel</h3>
            <img src='sample chart bar.png' alt='Trend Chart' style='max-width:100%;height:auto;border-radius:8px;box-shadow:0 2px 8px #0001;'/>
        </div>
        <div class='trend-pie'>
            <h3>Tools / Help</h3>
            <div style='background:#fff;border-radius:8px;padding:16px;right-padding:30px;width:1000px;max-width:100%;box-shadow:0 2px 8px #0001;height:auto;'>
            <b>Similarity Calculation Info:</b>
            <ul>
            <li><b>% Change:</b> Shows how a selected metric (e.g. Avg Temperature) has changed between two time periods.</li>
            <li><b>Difference From Reference:</b> Represents how close a station’s % change is to the reference station’s change.
            Smaller differences mean greater similarity. E.G: Ref Station: +0.88%,  Other Station: +0.59% → Difference = 0.29%</li>
            <li><b>Method:</b> Method:
            We calculate % change for each station using:  (Value in Period 2 - Value in Period 1) / Value in Period 1
            Then, we compare each station’s % change to the reference station’s % change to rank similarity.</li>
            </ul>
            </div>
        </div>
        </div>
        """ + CommonElements.getFooter() + "</body></html>";

        context.contentType("text/html; charset=UTF-8");
        context.html(html);
    }
}