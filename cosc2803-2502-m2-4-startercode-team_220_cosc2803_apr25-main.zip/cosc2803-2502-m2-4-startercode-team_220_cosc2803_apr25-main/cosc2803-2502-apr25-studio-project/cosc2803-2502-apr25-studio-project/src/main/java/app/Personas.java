package app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


//TODO: Implement getPersonasBar
public class Personas {
public static String getPersonasBar(String selectedPersona) {
    String[] personas = {"all-personas", "Leah Turner", "Henry McAllister", "Amelia Tran"};
    StringBuilder html = new StringBuilder();
    html.append("<div class='tab-bar' style=\"display:flex;background:linear-gradient(135deg, var(--primary-color), var(--accent-color));"
        + "border-radius:10px 10px 0 0;overflow:hidden;box-shadow:0 4px 6px rgba(0,0,0,0.08);margin-bottom:0;\">");
    for (String persona : personas) {
        String label = persona.equals("all-personas") ? "All Personas" : persona;
        String active = persona.equals(selectedPersona) ? " active" : "";
        html.append("<button type='button' class='tab-btn")
            .append(active)
            .append("' onclick=\"showPersona('").append(persona).append("')\"")
            .append(" style=\"flex:1;padding:15px 20px;border:none;background:transparent;color:#fff;font-size:16px;font-weight:600;cursor:pointer;transition:background 0.3s,color 0.3s;position:relative;text-align:center;outline:none;\">")
            .append(label)
            .append("</button>");
    }
    html.append("</div>");
    html.append("""
    <script>
    function showPersona(persona) {
        const container = document.getElementById('persona-block-container');
        if(persona === 'all-personas'){
            fetch('/persona-block?name=all-personas')
                .then(res => res.text())
                .then(html => {
                    container.innerHTML = html;
                });
            return;
        }
        fetch('/persona-block?name=' + encodeURIComponent(persona))
            .then(res => res.text())
            .then(html => {
                container.innerHTML = html;
            });
    }
    </script>
    """);
    return html.toString();
}    
    public static String[] getPersonaDetails(String name){
        String[] persona = new String[13];
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        try (Connection conn = DriverManager.getConnection(dbPath)) {
            String sql = "SELECT * FROM Personas WHERE Name = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                persona[0] = rs.getString("Name");
                persona[1] = rs.getString("Age");
                persona[2] = rs.getString("Gender");
                persona[3] = rs.getString("Location");
                persona[4] = rs.getString("Occupation");
                persona[5] = rs.getString("Education");
                persona[6] = rs.getString("Family");
                persona[7] = rs.getString("Tech Affinity");
                persona[8] = rs.getString("Background");
                persona[9] = rs.getString("Goals");
                persona[10] = rs.getString("Needs");
                persona[11] = rs.getString("Skills");
                persona[12] = rs.getString("Design");
            } else {
                System.out.println("No persona found for name: " + name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return persona;
    }
    //TODO: Implement getPersonaBlock
    public static String getPersonaBlock(String[] persona) {
        if (persona == null || persona[0] == null) {
            return "<div class='persona-block'>Persona not found.</div>";
        }
        String html = ""
            + "<div class='persona-block' style=\"background:#fff;border-radius:10px;box-shadow:0 2px 8px rgba(0,0,0,0.07);padding:24px 32px;margin:24px 0;\">"
            + "  <h2 style=\"margin-top:0;color:var(--primary-color);\">" + persona[0] + "</h2>"
            + "  <ul style=\"list-style:none;padding:0;\">"
            + "    <li><strong>Age:</strong> " + persona[1] + "</li>"
            + "    <li><strong>Gender:</strong> " + persona[2] + "</li>"
            + "    <li><strong>Location:</strong> " + persona[3] + "</li>"
            + "    <li><strong>Occupation:</strong> " + persona[4] + "</li>"
            + "    <li><strong>Education:</strong> " + persona[5] + "</li>"
            + "    <li><strong>Family:</strong> " + persona[6] + "</li>"
            + "    <li><strong>Tech Affinity:</strong> " + persona[7] + "</li>"
            + "    <li><strong>Background:</strong> " + persona[8] + "</li>"
            + "    <li><strong>Goals:</strong> " + persona[9] + "</li>"
            + "    <li><strong>Needs:</strong> " + persona[10] + "</li>"
            + "    <li><strong>Skills:</strong> " + persona[11] + "</li>"
            + "    <li><strong>Design:</strong> " + persona[12] + "</li>"
            + "  </ul>"
            + "</div>";
        return html;
    }
    
    public static String getAllBlock() {
        StringBuilder html = new StringBuilder();
        html.append("<div class='persona-grid' style='display: flex; gap: 24px; flex-wrap: wrap;'>");
        String dbPath = "jdbc:sqlite:cosc2803-2502-apr25-studio-project/cosc2803-2502-apr25-studio-project/database/climate.db";
        try (Connection conn = DriverManager.getConnection(dbPath);
             PreparedStatement ps = conn.prepareStatement("SELECT Name FROM Personas");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String name = rs.getString("Name");
                String[] persona = getPersonaDetails(name);
                html.append(getPersonaBlock(persona));
            }
        } catch (Exception e) {
            html.append("<div style='color:red;'>Error loading personas: ").append(e.getMessage()).append("</div>");
        }
        html.append("</div>");
        return html.toString();
    }





}
