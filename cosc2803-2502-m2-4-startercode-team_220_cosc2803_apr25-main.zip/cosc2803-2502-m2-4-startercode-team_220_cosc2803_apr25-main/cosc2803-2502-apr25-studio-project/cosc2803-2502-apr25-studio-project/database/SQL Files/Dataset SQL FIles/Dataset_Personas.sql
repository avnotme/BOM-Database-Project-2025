INSERT INTO PersonasDataset (Data, Attribute, Description) VALUES
('Name', 'Demographic Detail', 'The name of the persona.'),
('Age', 'Demographic Detail', 'The age of the persona.'),
('Gender', 'Demographic Detail', 'The gender of the persona.'),
('Location', 'Demographic Detail', 'The geographical location of the persona.'),
('Occupation', 'Demographic Detail', 'The occupation or profession of the persona.'),
('Education', 'Demographic Detail', 'The educational background of the persona.'),
('Family', 'Demographic Detail', 'Information about the persona''s family status.'),
('Tech Affinity', 'Behavioral Detail', 'The persona''s comfort level and interest in technology.');
