INSERT INTO TeamDataset (Data, Attribute, Description) VALUES
('Name', 'Team Member Detail', 'The name of the team member.'),
('Student ID', 'Team Member Detail', 'The student ID of the team member.'),
('Subtask', 'Team Member Detail', 'The subtask assigned to the team member.');
