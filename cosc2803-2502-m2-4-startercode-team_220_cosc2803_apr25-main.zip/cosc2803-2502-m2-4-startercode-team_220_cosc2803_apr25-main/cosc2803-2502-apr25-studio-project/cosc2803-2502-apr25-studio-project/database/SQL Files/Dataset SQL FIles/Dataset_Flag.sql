INSERT INTO FlagDataset (Data, Attribute, Description) VALUES
('Flag', 'Flag', 'The Flag as provided in the Databsae')
('Description', 'Description', 'The description of the Flag as provided in the Database');

