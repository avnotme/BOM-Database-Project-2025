INSERT INTO LocationDataset (Data, Attribute, Description) VALUES
('Site', 'ID', 'Unique identifier for the weather station site.'),
('Name', 'Name', 'Official name of the weather station or location.'),
('Lat', 'Latitude', 'Latitude coordinate of the location.'),
('Long', 'Longtitude', 'Longitude coordinate of the location.'),
('State', 'State or Territory', 'State or territory where the location is situated (e.g., VIC, NSW).'),
('Region', 'Region', 'Geographical region of the location.');
