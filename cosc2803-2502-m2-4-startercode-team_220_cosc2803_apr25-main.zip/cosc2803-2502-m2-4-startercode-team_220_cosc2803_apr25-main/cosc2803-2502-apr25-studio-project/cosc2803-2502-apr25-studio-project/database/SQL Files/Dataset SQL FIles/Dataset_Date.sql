INSERT INTO DateDataset (Data, Attribute, Description) VALUES
('Date', 'Date Attribute', 'The specific date (e.g., YYYY-MM-DD).'),
('DayOfWeek', 'Date Attribute', 'The name of the day of the week (e.g., Monday, Tuesday).'),
('Week', 'Date Attribute', 'The week number within the year.'),
('Month', 'Date Attribute', 'The name of the month (e.g., January, February).'),
('MonthNum', 'Date Attribute', 'The numerical representation of the month (1-12).'),
('Quarter', 'Date Attribute', 'The quarter of the year (1-4).'),
('Half', 'Date Attribute', 'The half of the year (1st or 2nd half).'),
('Year', 'Date Attribute', 'The four-digit year.'),
('HalfDecade', 'Date Attribute', 'The five-year period (e.g., 2020 for 2020-2024).'),
('Decade', 'Date Attribute', 'The ten-year period (e.g., 2020 for 2020-2029).');
