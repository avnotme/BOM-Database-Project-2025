INSERT INTO MetadataDataset (Data, Attribute, Description) VALUES
('Label', 'Natural Language Label', 'A Natural Language Label for the Data Attribute'),
('Field', 'Field Name', 'The name of the field as recorded in the other datasets'),
('Description', 'Description', 'A description of the data attribute'),
('Unit', 'Measurement Unit', 'The unit of measurement for the data (e.g., mm, °C, %)'),
('Purpose', 'Purpose', 'The purpose of the data attribute in the dataset');
